IOC过程分析：
1、将xml解析成 Map<beanName, BeanDefinition> beanDefinitionMap对象
    1.1、首先将XML解析成ducument对象(XmlBeanDefinitionReader.java中)
    1.2、遍历document对象中的element元素，使用委托模式将每个标签(component)解析成BeanDefinition对象
        1.2.1、先解析标签自身，即获取attribute(name、class)，并将其放到beanDefinition对象的属性中
        1.2.2、获取当前标签的子标签(property)集合
        1.2.3、创建PropertyValue对象的集合，循环遍历子标签
        1.2.4、创建PropertyValue对象，解析每个子标签的attribute并填充到propertyvalue对象中，再将其添加到propertyValue集合中
        1.2.5、将propertyValue对象放进beanDefinition属性中
    1.3、将解析到的BeanDefinition对象添加到beanDefinitionMap中
2、根据beanName创建bean对象
    2.1、先从singletonObjects中获取bean对象(所有创建好的bean对象都会保存在Map<String, Object> singletonObjects对象中)
    2.2、如果获取不到就从circularObject对象中获取bean对象(为了防止循环注入，所有对象在初始化之后，没填充属性之前，就会放到Map<String, Object> circularObject对象中)
    2.3、如果没有获取到bean对象，就从beanDefinitionMap中拿到对应的BeanDefinition对象，利用反射初始化需要的bean对象
    2.4、将上一步中初始化的对象放到circularObject这个Map中(此时这个对象只是被初始化了，属性没有填充，还不能使用)
    2.5、获取BeanDefinition中的List<PropertyValue>，并循环遍历
    2.6、如果是一般属性就利用反射直接赋值；如果是引用类型，就从2.1的步骤开始递归，获取被引用的对象，并通过反射填充到当前bean的属性中
    2.7、bean对象属性全部填充之后，直接返回该对象即可


AOP过程分析：
1、创建一个接口BeanPostProcessor，其中有一个方法，postProcessAfterInitialization
2、创建一个自动代理类，实现上面的方法，在框架启动时实例化该自动代理类，并注册到Map<beanName, BeanPostProcessor>中
3、在IOC每次返回完整bean对象之前都遍历该Map，并执行BeanPostProcessor中的方法(@Aspect类不执行，也就是说它不能被代理)
    3.1、该方法在第一次执行时会查找到所有定义的切面类，即有@Aspect标签的类
    3.2、再利用反射查找到其中的切点方法，对每个方法构造出一个相应的增强器，将这个增强器放到一个List<Advisor>中
    3.3、如果该方法不是第一次调用，就直接获取上面已经构造好的List<Advisor>集合
    3.4、遍历List<Advisor>集合，找到符合当前bean中每个方法的所有增强器，放到一个Map<method, List<Advisor>>中
    3.5、为当前bean对象创建动态代理
        3.5.1、使用JDK动态代理，实现InvocationHandler
        3.5.2、或者使用Cglib代理，实现MethodInterceptor
        3.5.3、构造上面两个代理类时都会传入Map<method, List<Advisor>>
    3.6、返回bean的代理对象
4、在调用被代理对象的某个方法时会先判断该方法有没有增强器，如果有就利用拦截器调用所有增强器；如果没有就直接调用该方法