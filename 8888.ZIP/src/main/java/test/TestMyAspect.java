package test;

import jdbc.spring.learn.TsmCounts;
import jdbc.spring.learn.TsmCountsDao;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMyAspect {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        TsmCountsDao tsmCountsDao = (TsmCountsDao)context.getBean("tsmCountsDao");
        tsmCountsDao.insertTsmCounts(new TsmCounts());
    }
}
