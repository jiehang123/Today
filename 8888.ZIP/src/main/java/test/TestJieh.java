package test;

import java.util.Map;

import com.jiehang.framework.core.BeanDefinition;
import com.jiehang.framework.core.XmlBeanFactory;

import cycle.dependency.spring.A;
import cycle.dependency.spring.B;
import cycle.dependency.spring.C;
import test.aspect.Demo;

public class TestJieh {
	public static void main(String[] args) {
        XmlBeanFactory beanFactory = new XmlBeanFactory("jiehangContext.xml");
        Demo demo = (Demo) beanFactory.getBean("demo");
        demo.test();
    }
}
