package test.aspect;

public class Demo{
    public void test() {
        System.out.println("test()...");
    }
}
