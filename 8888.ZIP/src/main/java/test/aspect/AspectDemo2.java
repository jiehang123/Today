package test.aspect;

import com.jiehang.framework.aop.JiehAspect;
import com.jiehang.framework.aop.JiehBefore;

@JiehAspect
public class AspectDemo2 {
    @JiehBefore("test.aspect.Demo.test")
    public void show() {
        System.out.println("Before 2...");
    }

    @JiehBefore("test.aspect.Demo.test")
    public void after() {
        System.out.println("Before 2 ...");
    }
}
