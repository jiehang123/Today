package test.aspect;

import com.jiehang.framework.aop.JiehAfter;
import com.jiehang.framework.aop.JiehAspect;
import com.jiehang.framework.aop.JiehBefore;

@JiehAspect
public class AspectDemo {

    @JiehBefore("test.aspect.Demo.test")
    public void show() {
        System.out.println("before");
    }

    @JiehAfter("test.aspect.Demo.test")
    public void after() {
        System.out.println("after");
    }

}
