package com.jiehang.framework.aop;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

public class JdkDynamicInvocationhandler implements InvocationHandler{

    private Object target;

    Map<Method, List<Advisor>> map;

//    private MethodInvocation methodInvocation;

    public JdkDynamicInvocationhandler(Map<Method, List<Advisor>> map, Object target) {
        this.target = target;
        this.map = map;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if(map.get(method) == null) {
            return method.invoke(target, args);
        }

//        MethodInvocation methodInvocation = new MethodInvocation(map);
        List<Advisor> advisors = map.get(method);
        for(Advisor advisor : advisors) {
            advisor.invokeAop();
        }

        return method.invoke(target, args);
    }
}
