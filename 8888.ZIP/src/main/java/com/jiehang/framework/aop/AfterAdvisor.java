package com.jiehang.framework.aop;

import java.lang.reflect.Method;

public class AfterAdvisor extends Advisor {
    AfterAdvisor(String executionStr, Object aopObject, Method aopMethod) {
        super(executionStr, aopObject, aopMethod);
    }
}
