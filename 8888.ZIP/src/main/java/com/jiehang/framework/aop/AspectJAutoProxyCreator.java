package com.jiehang.framework.aop;

import com.jiehang.framework.core.XmlBeanFactory;
import net.sf.cglib.proxy.Enhancer;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AspectJAutoProxyCreator implements BeanPostProcessor {

    private XmlBeanFactory xmlBeanFactory;

    private List<Advisor> advisorAll;

    public AspectJAutoProxyCreator(XmlBeanFactory xmlBeanFactory) {
        this.xmlBeanFactory = xmlBeanFactory;
    }

    @Override
    public Object postProcessAfterInitialization(Object obj) {
        if (advisorAll == null) {
            getAllAdvisor();
        }
        Map<Method, List<Advisor>> matchedAdvisor = getMatchedAdvisor(obj, advisorAll);
//        Object proxy = Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), obj.getClass().getInterfaces(), new JdkDynamicInvocationhandler(matchedAdvisor, obj));
        Enhancer enhancer = new Enhancer();
        enhancer.setSuperclass(obj.getClass());
        enhancer.setCallback(new CglibMethodInterceptor(matchedAdvisor, obj));
        return enhancer.create();
    }

    private Map<Method, List<Advisor>> getMatchedAdvisor(Object obj, List<Advisor> advisorAll) {
        Method[] methods = obj.getClass().getMethods();
        Map<Method, List<Advisor>> map = new HashMap<>();
        for (Method method : methods) {
            List<Advisor> methodAdvisorList = null;
            for (Advisor advisor : advisorAll) {
                if (advisor.isMatched(obj.getClass(), method)) {
                    if (methodAdvisorList == null) {
                        methodAdvisorList = new ArrayList<>();
                    }
                    methodAdvisorList.add(advisor);
                }
            }
            if (methodAdvisorList != null) {
                map.put(method, methodAdvisorList);
            }
        }
        return map;
    }

    private void getAllAdvisor() {
        Map<String, Object> mapAll = xmlBeanFactory.getSingletonObjects();
//        Map<String, Object> mapAll = new HashMap<>();
//        mapAll.put("testAnno", new AspectDemo());
        for (String key : mapAll.keySet()) {
            Object obj = mapAll.get(key);
            if (obj.getClass().getDeclaredAnnotation(JiehAspect.class) != null) {
                advisorAll = advisorAll == null ? new ArrayList<>() : advisorAll;
                doGetAllAdvisorByBean(obj, advisorAll);
            }
        }
    }

    private void doGetAllAdvisorByBean(Object obj, List<Advisor> list) {
        Method[] methods = obj.getClass().getMethods();
        if (methods != null && methods.length > 0) {
            for (Method method : methods) {
                Advisor advisor = createAdvisor(obj, method);
                if (advisor != null)
                    list.add(advisor);
            }
        }
    }

    private Advisor createAdvisor(Object obj, Method method) {
        Advisor advisor = null;
        if (method.getDeclaredAnnotation(JiehBefore.class) != null) {
            advisor = new BeforeAdvisor(method.getDeclaredAnnotation(JiehBefore.class).value(), obj, method);
        } else if (method.getDeclaredAnnotation(JiehAfter.class) != null) {
            advisor = new AfterAdvisor(method.getDeclaredAnnotation(JiehAfter.class).value(), obj, method);
        }
        return advisor;
    }
}




//
//@JiehAspect
//class AspectDemo {
//
//    @JiehBefore("com.jiehang.framework.aop.Demo.test")
//    public void show() {
//        System.out.println("before");
//    }
//
//    @JiehAfter("com.jiehang.framework.aop.Demo.test")
//    public void after() {
//        System.out.println("after");
//    }
//}
//
////interface DemoIntefarce {
////    public void test();
////}
//
//class Demo{
//    public void test() {
//        System.out.println("test()...");
//    }
//}
//
//class testMain {
//    public static void main(String[] args) {
//        AspectJAutoProxyCreator aspectJAutoProxyCreator = new AspectJAutoProxyCreator();
//        Demo demo = new Demo();
//        Demo proxy = (Demo)aspectJAutoProxyCreator.postProcessAfterInitialization(demo);
//        proxy.test();
//
//    }
//}