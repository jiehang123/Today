package com.jiehang.framework.aop;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.regex.Pattern;

public abstract class Advisor {

    private Pattern pattern;

    private Method method;

    private Object aopObject;

    private Method aopMethod;

    private Object[] aopObjects[];

    public Advisor(String executionStr, Object aopObject, Method aopMethod)  {
        pattern = Pattern.compile(executionStr);
        this.aopObject = aopObject;
        this.aopMethod = aopMethod;
    }

    public boolean isMatched(Class<?> clazz, Method method) {
        return pattern.matcher(clazz.getName()+ "." + method.getName()).find();
    }

    public Object invokeAop() throws InvocationTargetException, IllegalAccessException {
        return aopMethod.invoke(aopObject, null);
    }
}
