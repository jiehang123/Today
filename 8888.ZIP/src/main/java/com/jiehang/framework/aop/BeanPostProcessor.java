package com.jiehang.framework.aop;

public interface BeanPostProcessor {

    public Object postProcessAfterInitialization(Object object);

}
