package com.jiehang.framework.aop;

import java.lang.reflect.Method;

public class BeforeAdvisor extends Advisor{

    BeforeAdvisor(String executionStr, Object aopObject, Method aopMethod) {
        super(executionStr, aopObject, aopMethod);
    }
}
