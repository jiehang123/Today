package com.jiehang.framework.aop;

import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;
import org.aspectj.lang.annotation.After;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

public class CglibMethodInterceptor implements MethodInterceptor{

    private Object target;

    Map<Method, List<Advisor>> map;

    public CglibMethodInterceptor(Map<Method, List<Advisor>> map, Object target) {
        this.target = target;
        this.map = map;
    }

    @Override
    public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy) throws Throwable {
        if(map.get(method) == null) {
            return proxy.invokeSuper(obj, args);
        }

//        MethodInvocation methodInvocation = new MethodInvocation(map);
        List<Advisor> advisors = map.get(method);
        for(Advisor advisor : advisors) {
            if (advisor instanceof BeforeAdvisor)
                advisor.invokeAop();
        }
        Object result = proxy.invokeSuper(obj, args);
        for(Advisor advisor : advisors) {
            if (advisor instanceof AfterAdvisor)
                advisor.invokeAop();
        }

        return result;
    }
}
