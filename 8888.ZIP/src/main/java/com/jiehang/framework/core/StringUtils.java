package com.jiehang.framework.core;

public class StringUtils {

	public static boolean isEmpty(String str) {
		if (null == str || "".equals(str.trim()))
			return true;
		return false;
	}
	
	public static boolean isAllEmpty(String... strAll) {
		for(int i=0; i<strAll.length; i++) {
			if(strAll[i] != null || !"".equals(strAll[i]) ) {
				return false;
			}
		}
		return true;
	}

}
