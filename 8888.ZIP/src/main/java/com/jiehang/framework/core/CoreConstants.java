package com.jiehang.framework.core;

public class CoreConstants {
	
	public static final String SCHEMA_LANGUAGE_ATTRIBUTE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";

	public static final String XSD_SCHEMA_LANGUAGE = "http://www.w3.org/2001/XMLSchema";

	public static final String XSD_SCHEMA_JIEHANG = "jiehang_config.xsd";
	
	public static final String COMPONENT_NAME = "name";
	
	public static final String COMPONENT_CLASS = "class";
	
}
