package com.jiehang.framework.core;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.jiehang.framework.aop.AspectJAutoProxyCreator;
import com.jiehang.framework.aop.BeanPostProcessor;
import com.jiehang.framework.aop.JiehAspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * To parse xml and create all beans.
 * 
 * It's the beginning of my framework.
 * 
 * @author a620824
 *
 */
public class XmlBeanFactory {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(XmlBeanFactory.class);
	
	private XmlBeanDefinitionReader read = new XmlBeanDefinitionReader(this);
	
	/** All beanDefinition map from xml parsing */
	private final Map<String, BeanDefinition> beanDefinitionMap = new ConcurrentHashMap<String, BeanDefinition>();
	
	/** Cache of singleton object for circular refecrence */
	private final Map<String, Object> circularObject = new HashMap<String, Object>(16);
	
	/** All singleton object map */
	private final Map<String, Object> singletonObjects = new ConcurrentHashMap<String, Object>(256);

    private final List<BeanPostProcessor> beanPostProcessorList = new ArrayList<BeanPostProcessor>();

	
	/**
	 * Parse xml to beanDefinition map
	 * @param xmlPath
	 */
	public XmlBeanFactory(String xmlPath) {
		this.read.loadDocument(xmlPath);
		registerPostProcess();
		registerBean();
	}

	private void registerPostProcess() {
        beanPostProcessorList.add(new AspectJAutoProxyCreator(this));
	}

	private void registerBean() {
		for(String key : beanDefinitionMap.keySet()) {
			LOGGER.info("register bean [{}] in framework", key);
			singletonObjects.put(key, getBean(key));
		}
	}

	/**
	 * Get bean object
	 * @param name
	 * @return
	 */
	public Object getBean(String name) {
		return doGetBean(name);
	}

	private Object doGetBean(String name) {
		Object beanObject = getSingleton(name);
		if(beanObject == null) {
			beanObject = createBean(name);
		}
		singletonObjects.put(name, beanObject);
		return beanObject;
	}
	
	private Object createBean(String name) {
		BeanDefinition beanDefinition = beanDefinitionMap.get(name);
		return doCreateBean(beanDefinition);
	}

	private Object doCreateBean(BeanDefinition beanDefinition) {
		Object obj = createBeanInstance(beanDefinition);
		addSingleFactory(beanDefinition.getBeanName(), obj);
		try {
			populateValue(obj, beanDefinition);
		} catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
			e.printStackTrace();
		}
		if (obj.getClass().getDeclaredAnnotation(JiehAspect.class) == null) {
            obj = getProxyBeanObject(obj);
        }
		LOGGER.info("Finished creating instance of bean [{}]", beanDefinition.getBeanName());
		return obj;
	}



    /**
	 * populate values or refs
	 * @param obj
	 * @param beanDefinition
	 * @throws NoSuchFieldException
	 * @throws SecurityException
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	private void populateValue(Object obj, BeanDefinition beanDefinition) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		List<PropertyValue> valueList = beanDefinition.getPropertyValue();
		if(valueList != null) {
			for(PropertyValue value : valueList) {
				if(value.getValue() != null) {
					LOGGER.info("populate value [{}] into [{}]", value.getValue(), beanDefinition.getBeanName());
					Field field = obj.getClass().getDeclaredField(value.getName());
					field.setAccessible(true);
					field.set(obj, value.getValue());
				} else if(value.getRef() != null) {
					LOGGER.info("populate ref [{}] into [{}]", value.getRef(), beanDefinition.getBeanName());
					Object objRef = this.getBean(value.getRef());
					Field field = obj.getClass().getDeclaredField(value.getName());
					field.setAccessible(true);
					field.set(obj, objRef);
				}
			}
		}
	}

	/**
	 * by Caching a single factory map in Spring to solve circular reference
	 * 
	 * by Caching a single object map there without factory
	 * 
	 * @param beanName
	 * @param bean
	 */
	private void addSingleFactory(String beanName, Object bean) {
		circularObject.put(beanName, bean);
	}

	private Object createBeanInstance(BeanDefinition beanDefinition) {
		try {
			LOGGER.info("instance bean by refelection");
			Class<?> clazz = Class.forName(beanDefinition.getClassName());
			Object obj = clazz.newInstance();
			return obj;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return null;
	}

	private Object getSingleton(String name) {
		Object obj = singletonObjects.get(name);
		if(obj == null)
			obj = circularObject.get(name);
		return obj != null ? obj : null;
	}


    private Object getProxyBeanObject(Object obj) {
	    if (beanPostProcessorList != null && beanPostProcessorList.size() > 0) {
	        for (BeanPostProcessor processor : beanPostProcessorList) {
	            Object proxyObj = processor.postProcessAfterInitialization(obj);
	            if (proxyObj != null) {
	                return proxyObj;
                }
            }
        }
	    return null;
    }

    public Map<String, BeanDefinition> getBeanDefinitionMap() {
        return beanDefinitionMap;
    }

    public Map<String, Object> getSingletonObjects() {
        return singletonObjects;
    }
}
