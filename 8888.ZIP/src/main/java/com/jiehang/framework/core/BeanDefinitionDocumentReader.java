package com.jiehang.framework.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * create a delegation and use it to parse all default elements (Delegation Design Patterns)
 * 
 * @author a620824
 *
 */
public class BeanDefinitionDocumentReader {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BeanDefinitionDocumentReader.class);
	
	private BeanDefinitionParserDelegate delegate;
	
	private XmlBeanDefinitionReader xmlBeanDefinitionReader;
	
	public void registerBeanDefinition(Document doc, XmlBeanDefinitionReader xmlBeanDefinitionReader) {
		this.xmlBeanDefinitionReader = xmlBeanDefinitionReader;
		Element root = doc.getDocumentElement();
		doRegisterBeanDefinitions(root);
	}
	
	private BeanDefinitionParserDelegate createDelegate() {
		return new BeanDefinitionParserDelegate();
	}

	private void doRegisterBeanDefinitions(Element root) {
		LOGGER.info("ready to create delegate");
		this.delegate = createDelegate();
		parseBeanDefinitions(root, this.delegate);
	}

	private void parseBeanDefinitions(Element root, BeanDefinitionParserDelegate delegate) {
		if (delegate.isDefaultNamespace(root)) {
			NodeList nl = root.getChildNodes();
			for (int i = 0; i < nl.getLength(); i++) {
				Node node = nl.item(i);
				if (node instanceof Element) {
					Element ele = (Element) node;
					if (delegate.isDefaultNamespace(ele)) {
						parseDefaultElement(ele, delegate);
					}
				}
			}
		}
	}

	private void parseDefaultElement(Element ele, BeanDefinitionParserDelegate delgate) {
		BeanDefinition beanDefinition = delegate.parseBeanDefinitionElement(ele);
		BeanDefinitionReaderUtils.registerBeanDefinition(getXmlBeanDefinitionReader().getBeanFactory(), beanDefinition);
	}
	
	public XmlBeanDefinitionReader getXmlBeanDefinitionReader() {
		return xmlBeanDefinitionReader;
	}
	public void setXmlBeanDefinitionReader(XmlBeanDefinitionReader xmlBeanDefinitionReader) {
		this.xmlBeanDefinitionReader = xmlBeanDefinitionReader;
	}
	
}
