package com.jiehang.framework.core;

import java.util.List;

public class BeanDefinition {

	private String beanName;
	
	private String ClassName;
	
	private List<PropertyValue> propertyValue;


	public String getBeanName() {
		return beanName;
	}
	public void setBeanName(String beanName) {
		this.beanName = beanName;
	}
	public String getClassName() {
		return ClassName;
	}
	public void setClassName(String className) {
		ClassName = className;
	}
	public List<PropertyValue> getPropertyValue() {
		return propertyValue;
	}
	public void setPropertyValue(List<PropertyValue> propertyValue) {
		this.propertyValue = propertyValue;
	}
	
	
	@Override
	public String toString() {
		return "BeanDefinition [beanName=" + beanName + ", ClassName=" + ClassName + ", propertyValue=" + propertyValue
				+ "]";
	}
	
}
