package com.jiehang.framework.core;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * It's a delegation to parse and populate an Element
 * 
 * @author a620824
 *
 */
public class BeanDefinitionParserDelegate {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BeanDefinitionParserDelegate.class);
	
	private static final String PROPERTY 			= "property";
	private static final String BEANS_NAMESPACE_URI = "http://www.jiehang.com/autumn/schema/components";
	

	public boolean isDefaultNamespace(Node node) {
		String namespaceUri = node.getNamespaceURI();
		return namespaceUri == null || namespaceUri.trim().length() <=0  || BEANS_NAMESPACE_URI.equals(namespaceUri);
	}

	public BeanDefinition parseBeanDefinitionElement(Element ele) {
		String beanName = ele.getAttribute(CoreConstants.COMPONENT_NAME);
		String className = ele.getAttribute(CoreConstants.COMPONENT_CLASS);
		LOGGER.info("ready to parse element [{}] bean in delegate", beanName);
		BeanDefinition beanDefinition = new BeanDefinition();
		beanDefinition.setBeanName(beanName);
		beanDefinition.setClassName(className);
		populationBeanDefinitionElement(ele, beanDefinition);
		return beanDefinition;
	}
	
	private void populationBeanDefinitionElement(Element ele, BeanDefinition beanDefinition) {
		LOGGER.info("ready to population bean in delegate");
		parsePropertyElements(ele, beanDefinition);
	}
	
	private void parsePropertyElements(Element ele, BeanDefinition beanFinition) {
		LOGGER.info("ready to parse property and population to bean in delegate");
		NodeList nList = ele.getChildNodes();
		if(nList != null) {
			List<PropertyValue> valueList = new ArrayList<PropertyValue>();
			for (int i = 0; i < nList.getLength(); i++) {
				Node node = nList.item(i);
				if (node instanceof Element && PROPERTY.equals(node.getNodeName())) {
					String propertyName = ((Element) node).getAttribute("name");
					String propertyRef = ((Element) node).getAttribute("ref");
					String propertyValue = ((Element) node).getAttribute("value");
					PropertyValue value = new PropertyValue();
					if( StringUtils.isAllEmpty(propertyRef, propertyValue) || propertyRef.trim().length() > 0 && propertyValue.trim().length() > 0) {
						LOGGER.error("ref and value both is null or both is not null");
					} else if(!StringUtils.isEmpty(propertyRef)) {
						value.setRef(propertyRef);
					} else if(!StringUtils.isEmpty(propertyValue)) {
						value.setValue(propertyValue);
					}
					value.setName(propertyName);
					valueList.add(value);
				}
			}
			beanFinition.setPropertyValue(valueList != null && valueList.size() > 0 ? valueList : null);
		}
	}

}
