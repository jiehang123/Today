package com.jiehang.framework.core;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BeanDefinitionReaderUtils {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BeanDefinitionReaderUtils.class);

	public static void registerBeanDefinition(XmlBeanFactory beanFactory, BeanDefinition beanDefinition) {
		LOGGER.info("register beanDefinition [{}] into beanFactory", beanDefinition.getBeanName());
		
		Map<String, BeanDefinition> beanObjects = beanFactory.getBeanDefinitionMap();
		beanObjects.put(beanDefinition.getBeanName(), beanDefinition);
	}

}
