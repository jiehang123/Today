package com.jiehang.framework.core;

import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * To load xml and parse to a Document object.
 * 
 * Create an Reader to parse the document.
 * 
 * @author a620824
 *
 */
public class XmlBeanDefinitionReader {

	private static final Logger LOGGER = LoggerFactory.getLogger(XmlBeanDefinitionReader.class);
	
	private XmlBeanFactory beanFactory;
	
	public XmlBeanDefinitionReader(XmlBeanFactory beanFactory) {
		this.beanFactory = beanFactory;
	}

	public void loadDocument(String fileName) {
		LOGGER.info("Ready to load config from xml[{}]", fileName);
		InputSource inputSource = new InputSource(XmlBeanDefinitionReader.class.getClassLoader().getResourceAsStream(fileName));
		Document xmlDocument = doLoadDocument(inputSource);
		BeanDefinitionDocumentReader documentReader = new BeanDefinitionDocumentReader();
		documentReader.registerBeanDefinition(xmlDocument, this);
	}

	private Document doLoadDocument(InputSource inputSource) {
		LOGGER.info("begin to load xml config to document xml[{}]", inputSource);
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		builderFactory.setValidating(true);
		builderFactory.setNamespaceAware(true);
		builderFactory.setAttribute(CoreConstants.SCHEMA_LANGUAGE_ATTRIBUTE, CoreConstants.XSD_SCHEMA_LANGUAGE);
		DocumentBuilder builder;

		try {
			builder = builderFactory.newDocumentBuilder();

			builder.setEntityResolver(new EntityResolver() {
				@Override
				public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
					InputSource source = new InputSource(XmlBeanDefinitionReader.class.getClassLoader()
							.getResourceAsStream(CoreConstants.XSD_SCHEMA_JIEHANG));
					return source;
				}
			});
			builder.setErrorHandler(new ErrorHandler() {
				@Override
				public void warning(SAXParseException exception) throws SAXException {
					LOGGER.error("XmlComponentDefinitionReader.LoadDocument.warning");
					throw new RuntimeException();
				}

				@Override
				public void fatalError(SAXParseException exception) throws SAXException {
					LOGGER.error("XmlComponentDefinitionReader.LoadDocument.fatalError");
					throw new RuntimeException();
				}

				@Override
				public void error(SAXParseException exception) throws SAXException {
					LOGGER.error("XmlComponentDefinitionReader.LoadDocument.error");
					throw new RuntimeException();
				}
			});
			Document xmlDocument = builder.parse(inputSource);
			LOGGER.info("end to load xml config to document xml");
			return xmlDocument;
		} catch (Exception e) {
			LOGGER.error("parse error");
		}
		return null;
	}
	

	public XmlBeanFactory getBeanFactory() {
		return beanFactory;
	}
	public void setBeanFactory(XmlBeanFactory beanFactory) {
		this.beanFactory = beanFactory;
	}

}
