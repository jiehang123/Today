package aop.spring.learn;

public interface Orderable {

    int getOrder();
}