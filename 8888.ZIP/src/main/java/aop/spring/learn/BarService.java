package aop.spring.learn;

public interface BarService {
    void doSomething();

    void showSomething();
}