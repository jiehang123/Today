package aop.spring.learn;

@MyAspect(pointCut = "aop.spring.learn.BarServiceImp.doSomething")
public class MyLogAspect {
    public void before(Object[] args) {
//        System.out.println("before增强，args[0]:" + args[0] + ", args[1]:" + args[1]);
        System.out.println("before增强");

    }

    public void after(Object[] args) {
//        System.out.println("after增强，args[0]:" + args[0] + ", args[1]:" + args[1]);
        System.out.println("after增强");
    }

}

@MyAspect(pointCut = "aop.spring.learn.BarServiceImp.doSomething")
class NewLogAspect {
    public void before(Object[] args) {
//        System.out.println("before增强，args[0]:" + args[0] + ", args[1]:" + args[1]);
        System.out.println("newLogAspect before增强");

    }
}

@MyAspect(pointCut = "aop.spring.learn.BarServiceImp.doSomething")
class AddLogAspect {
    public void after(Object[] args) {
//        System.out.println("before增强，args[0]:" + args[0] + ", args[1]:" + args[1]);
        System.out.println("addLogAspect after增强");

    }
}