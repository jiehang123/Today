package aop.spring.learn;

import org.springframework.stereotype.Service;

@Service("barService")
public class BarServiceImp implements BarService {
    @Override
    public void doSomething() {
        System.out.println("执行原有业务逻辑...");
    }

    @Override
    public void showSomething() {
        System.out.println("show...");
    }
}