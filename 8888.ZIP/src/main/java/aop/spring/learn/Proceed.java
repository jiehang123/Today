package aop.spring.learn;

public interface Proceed {
    Object proceed() throws Throwable;
}