package aop.spring.learn;

import java.lang.reflect.Method;

public interface Advisor extends Orderable {

    boolean isMatch(Class<?> clazz, Method method);

    public Object invoke(MethodInvocation methodInvocation) throws Throwable;
}