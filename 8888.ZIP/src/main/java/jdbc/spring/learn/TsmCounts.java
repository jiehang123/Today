package jdbc.spring.learn;

import java.util.Date;

public class TsmCounts {

	private String fundId;

	private String countType;

	private Date startCountDate;

	private Integer totalCount;

	private Integer tdpPendingCount;

	public String getFundId() {
		return fundId;
	}

	public void setFundId(String fundId) {
		this.fundId = fundId;
	}

	public String getCountType() {
		return countType;
	}

	public void setCountType(String countType) {
		this.countType = countType;
	}

	public Date getStartCountDate() {
		return startCountDate;
	}

	public void setStartCountDate(Date startCountDate) {
		this.startCountDate = startCountDate;
	}

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	public Integer getTdpPendingCount() {
		return tdpPendingCount;
	}

	public void setTdpPendingCount(Integer tdpPendingCount) {
		this.tdpPendingCount = tdpPendingCount;
	}

	@Override
	public String toString() {
		return "TsmCounts [fundId=" + fundId + ", countType=" + countType + ", startCountDate=" + startCountDate
				+ ", totalCount=" + totalCount + ", tdpPendingCount=" + tdpPendingCount + "]";
	}
	
}
