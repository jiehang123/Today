package jdbc.spring.learn;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class TsmCountsDaoImpl extends JdbcDaoSupport implements TsmCountsDao {

	private final static String INSERT_SQL = "INSERT INTO TSM_COUNTS (FUND_ID, COUNT_TYPE, CREATED_AT, CREATED_BY, CREATED_FROM) VALUES (?, ?, SYSDATE, USER, SYS_CONTEXT('USERENV','HOST'))";

	private final static String QUERY_SQL = "select fund_id, count_type from tsm_counts where fund_id = 'TEST'";
	
	@Override
	public void insertTsmCounts(TsmCounts tsmCounts) {
//		getJdbcTemplate().update(INSERT_SQL, "TEST", "TEST");

//        getJdbcTemplate().query(new PreparedStatementCreator() {
//            @Override
//            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
//                return con.prepareStatement(QUERY_SQL);
//            }
//        }, new PreparedStatementSetter() {
//            @Override
//            public void setValues(PreparedStatement ps) throws SQLException {
//            }
//        }, new ResultSetExtractor() {
//
//            @Override
//            public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
//                return null;
//            }
//        });

//        TsmCounts result = getJdbcTemplate().queryForObject(QUERY_SQL, new TsmCountsMapper());
//        System.out.println(result);

        List<TsmCounts> list = getJdbcTemplate().query(QUERY_SQL, new TsmCountsMapper());
        System.out.println(list);

	}

    static class TsmCountsMapper extends ResultSetHelper implements RowMapper<TsmCounts> {
        @Override
        public TsmCounts mapRow(ResultSet rs, int rowNum) throws SQLException {
            TsmCounts tsmCounts = new TsmCounts();
            tsmCounts.setFundId(getString(rs, "FUND_ID"));
            tsmCounts.setCountType(getString(rs, "COUNT_TYPE"));
            return tsmCounts;
        }
    }

}
