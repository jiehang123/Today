package jdbc.spring.learn;

public interface TsmCountsDao {

	public void insertTsmCounts(TsmCounts tsmCounts);

}
