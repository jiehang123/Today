package jdbc.spring.learn;

import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

/**
 * For result set operations.
 * 
 * @author Jimmy Zhang
 * 
 */
public class ResultSetHelper
{
    /**
	 * @param resultSet
	 * @param index
	 * @return
	 * @throws SQLException
	 */
	public static Boolean getBoolean(ResultSet resultSet, int index)
		throws SQLException
	{
		Boolean value = resultSet.getBoolean(index);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public static Boolean getBoolean(ResultSet resultSet, String name)
		throws SQLException
	{
		Boolean value = resultSet.getBoolean(name);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param index
	 * @return
	 * @throws SQLException
	 */
	public static Byte getByte(ResultSet resultSet, int index)
		throws SQLException
	{
		Byte value = resultSet.getByte(index);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public static Byte getByte(ResultSet resultSet, String name)
		throws SQLException
	{
		Byte value = resultSet.getByte(name);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param index
	 * @return
	 * @throws SQLException
	 */
	public static Integer getInt(ResultSet resultSet, int index)
		throws SQLException
	{
		Integer value = resultSet.getInt(index);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public static Integer getInt(ResultSet resultSet, String name)
		throws SQLException
	{
		Integer value = resultSet.getInt(name);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param index
	 * @return
	 * @throws SQLException
	 */
	public static Long getLong(ResultSet resultSet, int index)
		throws SQLException
	{
		Long value = resultSet.getLong(index);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public static Long getLong(ResultSet resultSet, String name)
		throws SQLException
	{
		Long value = resultSet.getLong(name);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param index
	 * @return
	 * @throws SQLException
	 */
	public static BigDecimal getBigDecimal(ResultSet resultSet, int index)
		throws SQLException
	{
		BigDecimal value = resultSet.getBigDecimal(index);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public static BigDecimal getBigDecimal(ResultSet resultSet, String name)
		throws SQLException
	{
		BigDecimal value = resultSet.getBigDecimal(name);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param index
	 * @return
	 * @throws SQLException
	 */
	public static Number getNumber(ResultSet resultSet, int index)
		throws SQLException
	{
		Number value = (Number) resultSet.getObject(index);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public static Number getNumber(ResultSet resultSet, String name)
		throws SQLException
	{
		Number value = (Number) resultSet.getObject(name);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param index
	 * @return
	 * @throws SQLException
	 */
	public static Double getDouble(ResultSet resultSet, int index)
		throws SQLException
	{
		Double value = resultSet.getDouble(index);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public static Double getDouble(ResultSet resultSet, String name)
		throws SQLException
	{
		Double value = resultSet.getDouble(name);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param index
	 * @return
	 * @throws SQLException
	 */
	public static Float getFloat(ResultSet resultSet, int index)
		throws SQLException
	{
		Float value = resultSet.getFloat(index);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public static Float getFloat(ResultSet resultSet, String name)
		throws SQLException
	{
		Float value = resultSet.getFloat(name);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param index
	 * @return
	 * @throws SQLException
	 */
	public static String getString(ResultSet resultSet, int index)
		throws SQLException
	{
		String value = resultSet.getString(index);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public static String getString(ResultSet resultSet, String name)
		throws SQLException
	{
		String value = resultSet.getString(name);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param index
	 * @return
	 * @throws SQLException
	 */
	public static Date getDate(ResultSet resultSet, int index)
		throws SQLException
	{
		Date value = resultSet.getDate(index);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public static Date getDate(ResultSet resultSet, String name)
		throws SQLException
	{
		Date value = resultSet.getDate(name);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param index
	 * @return
	 * @throws SQLException
	 */
	public static Timestamp getTimestamp(ResultSet resultSet, int index)
		throws SQLException
	{
		Timestamp value = resultSet.getTimestamp(index);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public static Timestamp getTimestamp(ResultSet resultSet, String name)
		throws SQLException
	{
		Timestamp value = resultSet.getTimestamp(name);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param index
	 * @return
	 * @throws SQLException
	 */
	public static byte[] getBlob(ResultSet resultSet, int index)
		throws SQLException
	{
		Blob value = resultSet.getBlob(index);
		if (resultSet.wasNull()) {
			value = null;
		}

		return (value == null ? null : value.getBytes(0L, (int) value.length()));
	}

	/**
	 * @param resultSet
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public static byte[] getBlob(ResultSet resultSet, String name)
		throws SQLException
	{
		Blob value = resultSet.getBlob(name);
		if (resultSet.wasNull()) {
			value = null;
		}

		return (value == null ? null : value.getBytes(0L, (int) value.length()));
	}

	/**
	 * @param resultSet
	 * @param index
	 * @return
	 * @throws SQLException
	 */
	public static String getClob(ResultSet resultSet, int index)
		throws SQLException
	{
		Clob value = resultSet.getClob(index);
		if (resultSet.wasNull()) {
			value = null;
		}

		return (value == null ? null : value.getSubString(0L,
				(int) value.length()));
	}

	/**
	 * @param resultSet
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public static String getClob(ResultSet resultSet, String name)
		throws SQLException
	{
		Clob value = resultSet.getClob(name);
		if (resultSet.wasNull()) {
			value = null;
		}

		return (value == null ? null : value.getSubString(0L,
				(int) value.length()));
	}

	/**
	 * @param resultSet
	 * @param index
	 * @return
	 * @throws SQLException
	 */
	public static Object getObject(ResultSet resultSet, int index)
		throws SQLException
	{
		Object value = resultSet.getObject(index);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

	/**
	 * @param resultSet
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public static Object getObject(ResultSet resultSet, String name)
		throws SQLException
	{
		Object value = resultSet.getObject(name);
		if (resultSet.wasNull()) {
			value = null;
		}

		return value;
	}

}
