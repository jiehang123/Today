package cycle.dependency.spring;

public class A {
	
	private B b;
	private String str;

	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}

	public B getB() {
		return b;
	}

	public void setB(B b) {
		this.b = b;
	}
	
	public void display() {
		System.out.println("str:" + str + "----" + b);
	}
	
}
