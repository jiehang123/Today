package proxy.jdk;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

interface MyBeanIn{
    public void display();
}
public class MyBean implements MyBeanIn{
    @Override
    public void display() {
        System.out.println("myBean.display()");
    }
}

class MyInvocationHandler implements InvocationHandler {

    private Object obj;

    public MyInvocationHandler(Object obj) {
        this.obj = obj;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.println("before");
        Object result = method.invoke(obj, args);
        System.out.println("after");
        return result;
    }
}

class client {
    public static void main(String[] args) {
        MyBean myBean = new MyBean();
        InvocationHandler invocationHandler = new MyInvocationHandler(myBean);
        MyBeanIn proxyBean = (MyBeanIn) Proxy.newProxyInstance(myBean.getClass().getClassLoader(), myBean.getClass().getInterfaces(), invocationHandler);
        proxyBean.display();
    }
}
