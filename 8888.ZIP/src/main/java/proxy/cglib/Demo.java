package proxy.cglib;

import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

import java.lang.reflect.Method;

public class Demo {
    public void show() {
        System.out.println("show..");
    }

    public void dis() {
        System.out.println("dis..");
    }
}

class MyMethodInterceptor implements MethodInterceptor {

    @Override
    public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
        System.out.println("before demo");
        Object object = methodProxy.invokeSuper(o, objects);
        System.out.println("after demo");
        return object;
    }
}

class Client{
    public static void main(String[] args) {
        Demo demo = new Demo();

        Enhancer enhancer = new Enhancer();
        enhancer.setSuperclass(Demo.class);
        enhancer.setCallback(new MyMethodInterceptor());
        Demo proxy = (Demo) enhancer.create();

        proxy.dis();
    }
}