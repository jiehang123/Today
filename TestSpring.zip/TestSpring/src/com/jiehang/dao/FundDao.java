package com.jiehang.dao;

import java.util.List;
import java.util.Map;

import com.jiehang.model.Fund;

public interface FundDao {
	
	public abstract void insertUser(Fund user);
	
	public abstract List<Fund> queryUser();
	
	public abstract List<Fund> queryUser1();
	
	public abstract List<Fund> queryUser2();
	
	/**
	 * Spring4.x don't support this method, Instead of Using RowMapper to package datas into List.
	 * @return
	 */
	public abstract List<Fund> queryUser3();
	
	/**
	 * The same as above.
	 * @return
	 */
	public abstract Fund queryUser4();
	
	public abstract Map<String, Object> queryUser5();
	
	public abstract void queryUser6();
}
