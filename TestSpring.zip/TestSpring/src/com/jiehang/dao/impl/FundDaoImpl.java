package com.jiehang.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.jiehang.dao.FundDao;
import com.jiehang.model.Fund;
import com.jiehang.util.ResultSetHelper;
import com.jiehang.util.ResultSetMapper;

public class FundDaoImpl extends JdbcDaoSupport implements FundDao{
	
	public void insertUser(Fund user) {
		this.getJdbcTemplate().execute(new PreparedStatementCreator() {
			
			public PreparedStatement createPreparedStatement(Connection arg0)
					throws SQLException {
				// TODO Auto-generated method stub
				return null;
			}
		}, new PreparedStatementCallback<Integer>() {

			public Integer doInPreparedStatement(PreparedStatement arg0)
					throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				return null;
			}
		});
	}
	
	public List<Fund> queryUser() {
		String sql = "SELECT * FROM TSM_COUNT WHERE FUND_ID = 'GC54' AND POST_START_TIME IS NOT NULL";
		List<Fund> funds = this.getJdbcTemplate().query(sql, new RowMapper<Fund>() {
			public Fund mapRow(ResultSet resultset, int i) throws SQLException {
				return (new FundMapper()).mapResultSet(resultset, i);
			}
		});
		return funds;
	}
	
	public List<Fund> queryUser1() {
		String sql = "SELECT * FROM TSM_COUNT WHERE CREATED_AT > to_date('01-02-17 00:00:00','dd-MM-yy hh24:mi:ss')";
		final List<Fund> funds = new ArrayList<Fund>();
		this.getJdbcTemplate().query(sql, new RowCallbackHandler() {
			public void processRow(ResultSet resultset) throws SQLException {
				funds.add((new FundMapper().mapResultSet(resultset, 0)));
			}
		});
		return funds;
	}
	
	public List<Fund> queryUser2() {
		String sql = "SELECT * FROM TSM_COUNT WHERE CREATED_AT > to_date('01-02-17 00:00:00','dd-MM-yy hh24:mi:ss')";
		List<Fund> list = this.getJdbcTemplate().query(sql, new ResultSetExtractor<List<Fund>>() {
			public List<Fund> extractData(ResultSet resultset) throws SQLException,
					DataAccessException {
				List<Fund> funds = new ArrayList<Fund>();
				while(resultset.next()) {
					funds.add((new FundMapper().mapResultSet(resultset, 0)));
				}
				return funds;
			}
		});
		return list;
		
		/*String sql = "SELECT * FROM TSM_COUNT WHERE CREATED_AT > to_date('01-02-17 00:00:00','dd-MM-yy hh24:mi:ss')";
		final List<Fund> list = new ArrayList<Fund>();
		this.getJdbcTemplate().query(sql, new ResultSetExtractor<Fund>() {
			public Fund extractData(ResultSet resultset) throws SQLException,
					DataAccessException {
				while(resultset.next()) {
					list.add((new FundMapper().mapResultSet(resultset, 0)));
				}
				return null;
			}
		});
		return list;*/
	}
	
	/**
	 * Spring4.x don't support this method, Instead of Using RowMapper to package datas into List.
	 * @return
	 */
	public List<Fund> queryUser3() {
		String sql = "SELECT * FROM TSM_COUNT WHERE CREATED_AT > to_date('01-02-17 00:00:00','dd-MM-yy hh24:mi:ss')";
		return this.getJdbcTemplate().queryForList(sql, Fund.class);
	}
	
	/**
	 * The same as above.
	 * @return
	 */
	public Fund queryUser4() {
		String sql = "SELECT * FROM TSM_COUNT WHERE CREATED_AT > to_date('01-02-17 00:00:00','dd-MM-yy hh24:mi:ss')";
		return this.getJdbcTemplate().queryForObject(sql, Fund.class);
	}
	
	public Map<String, Object> queryUser5() {
		String sql = "SELECT * FROM TSM_COUNT WHERE CREATED_AT > to_date('01-02-17 00:00:00','dd-MM-yy hh24:mi:ss') and rownum < 2";
		return this.getJdbcTemplate().queryForMap(sql);
	}
	
	public void queryUser6() {
		String sql = "SELECT * FROM TSM_COUNT WHERE CREATED_AT > to_date('01-02-17 00:00:00','dd-MM-yy hh24:mi:ss')";
		SqlRowSet srs = this.getJdbcTemplate().queryForRowSet(sql);
		while(srs.next()) {
			System.out.println("fundId: " + srs.getString("FUND_ID"));
		}
	}
	
	class FundMapper extends ResultSetHelper implements ResultSetMapper {
		public Fund mapResultSet(ResultSet resultSet, int i)
				throws SQLException {
			Fund fund = new Fund();
			fund.setFundId(getString(resultSet, "FUND_ID"));
			fund.setCreatedAt(getTimestamp(resultSet, "CREATED_AT"));
			
			/*Fund fund = new Fund();
			super.FileMatchColumn(resultSet, fund);*/
			
			return fund;
		}
	}
	
}
