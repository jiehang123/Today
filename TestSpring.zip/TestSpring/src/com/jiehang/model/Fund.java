package com.jiehang.model;

import java.util.Date;
import java.util.List;

public class Fund {
	private String fundId;
	private Date navDeadline;
	private String deadLineType;
	private Integer instrucationCount;
	private Integer totalOpenTradeCount;
	private Integer validatedCount;
	private Integer tdpOpenTradeCount;
	private Integer completedCount;
	private Date previousDeadline;
	private String activeFlag;
	private Date postStartTime;
	private String createdBy;
	private Date createdAt;
    private String createdFrom;
    private String updatedBy;
    private Date updatedAt;
    private String updatedFrom;
	public String getFundId() {
		return fundId;
	}
	public void setFundId(String fundId) {
		this.fundId = fundId;
	}
	public Date getNavDeadline() {
		return navDeadline;
	}
	public void setNavDeadline(Date navDeadline) {
		this.navDeadline = navDeadline;
	}
	public String getDeadLineType() {
		return deadLineType;
	}
	public void setDeadLineType(String deadLineType) {
		this.deadLineType = deadLineType;
	}
	public Integer getInstrucationCount() {
		return instrucationCount;
	}
	public void setInstrucationCount(Integer instrucationCount) {
		this.instrucationCount = instrucationCount;
	}
	public Integer getTotalOpenTradeCount() {
		return totalOpenTradeCount;
	}
	public void setTotalOpenTradeCount(Integer totalOpenTradeCount) {
		this.totalOpenTradeCount = totalOpenTradeCount;
	}
	public Integer getValidatedCount() {
		return validatedCount;
	}
	public void setValidatedCount(Integer validatedCount) {
		this.validatedCount = validatedCount;
	}
	public Integer getTdpOpenTradeCount() {
		return tdpOpenTradeCount;
	}
	public void setTdpOpenTradeCount(Integer tdpOpenTradeCount) {
		this.tdpOpenTradeCount = tdpOpenTradeCount;
	}
	public Integer getCompletedCount() {
		return completedCount;
	}
	public void setCompletedCount(Integer completedCount) {
		this.completedCount = completedCount;
	}
	public Date getPreviousDeadline() {
		return previousDeadline;
	}
	public void setPreviousDeadline(Date previousDeadline) {
		this.previousDeadline = previousDeadline;
	}
	public String getActiveFlag() {
		return activeFlag;
	}
	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}
	public Date getPostStartTime() {
		return postStartTime;
	}
	public void setPostStartTime(Date postStartTime) {
		this.postStartTime = postStartTime;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public String getCreatedFrom() {
		return createdFrom;
	}
	public void setCreatedFrom(String createdFrom) {
		this.createdFrom = createdFrom;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public String getUpdatedFrom() {
		return updatedFrom;
	}
	public void setUpdatedFrom(String updatedFrom) {
		this.updatedFrom = updatedFrom;
	}
	@Override
	public String toString() {
		return "Fund [fundId=" + fundId + ", navDeadline=" + navDeadline
				+ ", deadLineType=" + deadLineType + ", instrucationCount="
				+ instrucationCount + ", totalOpenTradeCount="
				+ totalOpenTradeCount + ", validatedCount=" + validatedCount
				+ ", tdpOpenTradeCount=" + tdpOpenTradeCount
				+ ", completedCount=" + completedCount + ", previousDeadline="
				+ previousDeadline + ", activeFlag=" + activeFlag
				+ ", postStartTime=" + postStartTime + ", createdBy="
				+ createdBy + ", createdAt=" + createdAt + ", createdFrom="
				+ createdFrom + ", updatedBy=" + updatedBy + ", updatedAt="
				+ updatedAt + ", updatedFrom=" + updatedFrom + "]";
	}
	
}
