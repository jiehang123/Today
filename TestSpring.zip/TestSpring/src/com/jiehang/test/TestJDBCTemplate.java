package com.jiehang.test;

import java.util.List;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.jiehang.model.Fund;
import com.jiehang.service.FundService;

public class TestJDBCTemplate extends JdbcDaoSupport{
	
	private static FundService fundService = getBean();
	
	public static FundService getBean() {
		ApplicationContext ac = new FileSystemXmlApplicationContext("/src/applicationContext.xml"); 
		return (FundService) ac.getBean("fundService");
	}
	
	@Test
	public void test() {
		List<Fund> funds = fundService.queryUser();
		printlnFundList(funds);
		Assert.assertNotNull(funds);
	}
	
	@Test
	public void test1() {
		List<Fund> funds = fundService.queryUser1();
		printlnFundList(funds);
		Assert.assertNotNull(funds);
	}
	
	@Test
	public void test2() {
		List<Fund> funds = fundService.queryUser2();
		printlnFundList(funds);
		Assert.assertNotNull(funds);
	}
	
	@Test
	public void test3() {
		List<Fund> funds = fundService.queryUser3();
		System.out.println(funds.size());
		Assert.assertNotNull(funds);
	}
	
	@Test
	public void test4() {
		Fund fund = fundService.queryUser4();
		System.out.println(fund);
		Assert.assertNotNull(fund);
	}
	
	@Test
	public void test5() {
		Map<String, Object> map = fundService.queryUser5();
		System.out.println(map);
		Assert.assertNotNull(map);
	}
	
	@Test
	public void test6() {
		fundService.queryUser6();
	}
	
	public void printlnFundList(List<Fund> funds) {
		for (int i = 0; i < funds.size(); i++) {
			System.out.println(funds.get(i));
		}
	}

}
