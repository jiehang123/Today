package com.jiehang.service.impl;

import java.util.List;
import java.util.Map;

import com.jiehang.dao.FundDao;
import com.jiehang.model.Fund;
import com.jiehang.service.FundService;

public class FundServiceImpl implements FundService{
	
	private FundDao fundDao;
	
	public void setFundDao(FundDao fundDao) {
		this.fundDao = fundDao;
	}

	public void insertUser(Fund user) {
		// TODO Auto-generated method stub
	}

	public List<Fund> queryUser() {
		List<Fund> funds = fundDao.queryUser();
		return funds;
	}

	public List<Fund> queryUser1() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Fund> queryUser2() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Fund> queryUser3() {
		// TODO Auto-generated method stub
		return null;
	}

	public Fund queryUser4() {
		// TODO Auto-generated method stub
		return null;
	}

	public Map<String, Object> queryUser5() {
		// TODO Auto-generated method stub
		return null;
	}

	public void queryUser6() {
		// TODO Auto-generated method stub
		
	}

}
