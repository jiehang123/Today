package com.txc2.smoke.schedule;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.txc2.smoke.dao.SmokeDao;

@Component
public class ScheduleTask {
	
	@Autowired
	private SmokeDao smokeDao; 
	
	@Scheduled(fixedRate = 10000)
	public void doScheduleTask() {
		smokeDao.getSitDeployedProfiles();
		smokeDao.getProdDeployedProfiles();
	}
	
}
