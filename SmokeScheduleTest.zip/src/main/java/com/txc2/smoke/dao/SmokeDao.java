package com.txc2.smoke.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class SmokeDao {

	@Autowired
	@Qualifier("prodJdbcTemplate")
	private JdbcTemplate prodJdbcTemplate;

	@Autowired
	@Qualifier("sitJdbcTemplate")
	private JdbcTemplate sitJdbcTemplate;

	
	public List<String> getProdDeployedProfiles() {
		List<String> list = new ArrayList<String>();
		prodJdbcTemplate.query("select editor framework_name from pms_operator", new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				list.add(rs.getString("framework_name"));
				return null;
			}
		});
		System.out.println(list);
		return list;
	}
	
	public List<String> getSitDeployedProfiles() {
		List<String> list = new ArrayList<String>();
		sitJdbcTemplate.query("select name framework_name from blog_category", new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				list.add(rs.getString("framework_name"));
				return null;
			}
		});
		System.out.println(list);
		return list;
	}
}
