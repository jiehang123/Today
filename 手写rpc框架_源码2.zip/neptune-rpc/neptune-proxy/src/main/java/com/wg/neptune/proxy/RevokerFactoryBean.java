package com.wg.neptune.proxy;

import com.wg.neptune.model.ConsumerService;
import com.wg.neptune.model.ProviderService;
import com.wg.neptune.proxy.RevokerProxy;
import com.wg.neptune.zookeeper.RegisterCenter;
import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;

import java.util.List;
import java.util.Map;

/**
 * 服务引入
 */
public class RevokerFactoryBean implements FactoryBean, InitializingBean {

    //服务接口
    private Class<?> targetInterface;
    //超时时间
    private int timeout;
    //服务bean
    private Object serviceObject;

    //负载均衡策略
    private String clusterStrategy;

    //服务提供者唯一标识
    private String appKey;

    //服务分组组名
    private String groupName = "default";


    public Object getObject() throws Exception {
        return serviceObject;
    }


    public Class<?> getObjectType() {
        return targetInterface;
    }



    public boolean isSingleton() {
        return true;
    }


    public void afterPropertiesSet() throws Exception {

        //获取服务注册中心
        RegisterCenter registerCenter = RegisterCenter.singleton();
        //初始化服务提供者列表到本地缓存
        registerCenter.initProviderMap(appKey, groupName);

        //初始化Netty Channel
        Map<String, List<ProviderService>> providerMap = registerCenter.getServiceMap4Consumer();
        if (MapUtils.isEmpty(providerMap)) {
            throw new RuntimeException("service provider list is empty.");
        }
        //获取服务的代理对象
        RevokerProxy revokerProxy =new  RevokerProxy(targetInterface, timeout, clusterStrategy);
        this.serviceObject = revokerProxy.getProxy();
        //将消费者信息注册到注册中心
        ConsumerService invoker = new ConsumerService();
        invoker.setServiceItf(targetInterface);
        invoker.setAppKey(appKey);
        invoker.setGroupName(groupName);
        registerCenter.registerConsemer(invoker);
    }


    public Class<?> getTargetInterface() {
        return targetInterface;
    }

    public void setTargetInterface(Class<?> targetInterface) {
        this.targetInterface = targetInterface;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public Object getServiceObject() {
        return serviceObject;
    }

    public void setServiceObject(Object serviceObject) {
        this.serviceObject = serviceObject;
    }

    public String getClusterStrategy() {
        return clusterStrategy;
    }

    public void setClusterStrategy(String clusterStrategy) {
        this.clusterStrategy = clusterStrategy;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
}
