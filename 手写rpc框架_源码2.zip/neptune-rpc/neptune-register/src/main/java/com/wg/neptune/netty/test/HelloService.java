package com.wg.neptune.netty.test;

/**
 * Created by mc on 18/7/10.
 */
public interface HelloService {

    public String say();
}
