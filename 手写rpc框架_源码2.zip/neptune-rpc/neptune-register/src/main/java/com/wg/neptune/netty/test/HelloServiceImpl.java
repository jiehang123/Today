package com.wg.neptune.netty.test;

/**
 * Created by mc on 18/7/10.
 */
public class HelloServiceImpl implements HelloService {

    public String say() {
        return "hello";
    }
}
