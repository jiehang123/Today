package com.wg.neptune.zookeeper;

import org.I0Itec.zkclient.IZkDataListener;
import org.I0Itec.zkclient.ZkClient;

/**
 * Created by mc on 18/5/25.
 */
public class ZkDome {

    public static void main(String[] args) throws InterruptedException {

        String zkServers = "127.0.0.1:2181";
        int connectionTimeout = 3000;

        ZkClient zkClient = new ZkClient(zkServers, connectionTimeout);

        String zkPath = "/zk-data";
        if(zkClient.exists(zkPath)){
            zkClient.delete(zkPath);
        }
        zkClient.createPersistent(zkPath);
        zkClient.writeData(zkPath,"我的zookeeper测试数据");
        //读取数据
        System.out.print(zkClient.readData(zkPath));
        //监听数据变化
        zkClient.subscribeDataChanges(zkPath, new IZkDataListener() {
            public void handleDataChange(String s, Object o) throws Exception {
                System.out.print("data changed:path"+s+";data:"+o);
            }

            public void handleDataDeleted(String s) throws Exception {

            }
        });

        zkClient.writeData(zkPath,"我的测试数据-2");

        Thread.sleep(10000);
        System.out.print("测试完毕");
    }

}
