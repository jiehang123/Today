package com.wg.neptune.netty.client;

import com.wg.neptune.model.RpcResponse;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 *
 * Title: NettyClientHandler
 */
public class NettyClientHandler extends SimpleChannelInboundHandler<RpcResponse> {

    private static final Logger logger = LoggerFactory.getLogger(NettyClientHandler.class);

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, RpcResponse rpcResponse) throws Exception {
        logger.info("客户端接受的消息: " + rpcResponse.toString());
        System.out.println("客户端接受的消息: " + rpcResponse.toString());
    }

    //
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("正在连接...");
        logger.info("正在连接... ");
        super.channelActive(ctx);
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
         System.out.println("连接关闭...");
        logger.info("连接关闭! ");
        super.channelInactive(ctx);
    }
}
