package com.wg.neptune.netty.client;

/**
 * Created by mc on 18/5/29.
 */
import com.wg.neptune.SerializeType;
import com.wg.neptune.model.RpcResponse;
import com.wg.neptune.netty.NettyDecoderHandler;
import com.wg.neptune.netty.NettyEncoderHandler;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;

/**
 *
 * Title: NettyClientFilter
 */
public class NettyClientFilter extends ChannelInitializer<SocketChannel> {

    @Override
    protected void initChannel(SocketChannel ch) throws Exception {
        ChannelPipeline ph = ch.pipeline();
        /*
         * 解码和编码，应和服务端一致
         * */
        //ph.addLast("framer", new DelimiterBasedFrameDecoder(8192, Delimiters.lineDelimiter()));
        ph.addLast("encoder", new NettyEncoderHandler(SerializeType.JACKSON));
        ph.addLast("decoder", new NettyDecoderHandler(RpcResponse.class,SerializeType.JACKSON));
        ph.addLast("handler", new NettyClientHandler()); //客户端的逻辑
    }
}