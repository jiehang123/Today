package com.wg.neptune.netty.server;

import com.wg.neptune.SerializeType;
import com.wg.neptune.model.RpcRequest;
import com.wg.neptune.netty.NettyDecoderHandler;
import com.wg.neptune.netty.NettyEncoderHandler;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;

/**
 * Created by mc on 18/5/29.
 */
public class NettyServerFilter extends ChannelInitializer<SocketChannel> {

    @Override
    protected void initChannel(SocketChannel ch) throws Exception {
        ChannelPipeline ph = ch.pipeline();
        // 以("\n")为结尾分割的 解码器
        //ph.addLast("framer", new DelimiterBasedFrameDecoder(8192, Delimiters.lineDelimiter()));
        // 解码和编码，应和客户端一致
        ph.addLast("encoder", new NettyEncoderHandler(SerializeType.JACKSON));
        ph.addLast("decoder", new NettyDecoderHandler(RpcRequest.class, SerializeType.JACKSON));
        ph.addLast("handler", new NettyServerHandler());// 服务端业务逻辑
    }
}
