package com.wg.neptune.zookeeper;

import com.wg.neptune.model.ConsumerService;
import com.wg.neptune.model.ProviderService;

import java.util.List;
import java.util.Map;

/**
 * Created by mc on 18/5/31.
 * 消费者注册接口
 */
public interface IConsumerRegister {

    /**
     * 初始化服务提供者信息
     */
    public  void  initProviderMap(String appKey, String groupName);

    /**
     * 初始化消费端服务提供者信息
     * @return
     */
    public Map<String ,List<ProviderService>> getServiceMap4Consumer();

    /**
     * 注册消费者至zk
     * @param consumerService
     */
    public void registerConsemer(final ConsumerService consumerService);
}
