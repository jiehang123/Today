package com.wg.neptune.zookeeper;

import com.wg.neptune.model.ProviderService;

import java.util.List;
import java.util.Map;

/**
 * provider注册中心抽象接口定义
 * Created by mc on 18/5/17.
 */
public interface IProviderRegister {

    /**
     * 注册服务提供者至zookeeper
     * @param providerServices
     */
    public void providerRegister(final List<ProviderService> providerServices);


    /**
     * 服务端获取服务提供者信息
     * @return
     */
    public Map<String,List<ProviderService>> getProviderServiceMap();
}
