package com.wg.neptune.cluster.enums;

/**
 * Created by mc on 18/6/6.
 */
public enum  ClusterEnum {

    IP_HASH(0, "ip hash负载均衡"),

    RANDOM(1,"随机负载均衡"),

    ROUND(2, "轮训负载均衡"),

    WEIGHT_ROUND(3, "权重轮询负载均衡"),

    WEIGHT_RANDOM(4, "权重随机负载均衡");

    private int code;
    private String msg;
    ClusterEnum(int code, String msg){
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public static ClusterEnum getEnum(String name) {
        for(ClusterEnum type : ClusterEnum.values()) {
            if(name.equals(type.name())) {
                return type;
            }
        }
        return ClusterEnum.RANDOM;
    }
}
