package com.wg.neptune.cluster.strategy;

import com.wg.neptune.cluster.Cluster;
import com.wg.neptune.model.ProviderService;

import java.util.List;

/**
 * Created by mc on 18/6/6.
 * 原地址ip hash
 */
public class IpHashClusterStrategy implements Cluster {

    /**
     * ip hash负载均衡算法
     * @param providerServices
     * @return
     */
    public ProviderService select(List<ProviderService> providerServices) {
        String ip = "1270.0.0.1";
        int hashCode = ip.hashCode();
        return providerServices.get(hashCode% providerServices.size());
    }
}
