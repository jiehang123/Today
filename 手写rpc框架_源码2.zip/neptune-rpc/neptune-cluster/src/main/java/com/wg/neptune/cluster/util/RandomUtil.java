package com.wg.neptune.cluster.util;

import java.util.Random;

/**
 * Created by mc on 18/6/6.
 */
public class RandomUtil {

    public static int getRandomNum(int max){
        Random rand = new Random();
        return rand.nextInt(max);
    }

    public static void main(String[] args) {
        System.out.print(getRandomNum(3));
    }
}
