package com.wg.neptune.cluster;

import com.google.common.collect.Maps;
import com.wg.neptune.cluster.enums.ClusterEnum;
import com.wg.neptune.cluster.strategy.*;

import java.util.Map;

/**
 * Created by mc on 18/6/6.
 * 负载均衡算法引擎
 */
public class ClusterEngine {

    private final static Map<ClusterEnum,Cluster>  map = Maps.newConcurrentMap();

    static {
        map.put(ClusterEnum.IP_HASH,new IpHashClusterStrategy());
        map.put(ClusterEnum.RANDOM,new RandomClusterStrategy());
        map.put(ClusterEnum.ROUND,new RoundClusterStrategy());
        map.put(ClusterEnum.WEIGHT_RANDOM,new WeightRandomClusterStrategy());
        map.put(ClusterEnum.WEIGHT_ROUND,new WeightRoundClusterStrategy());
    }

    /**
     * 获取负载均衡算法
     * @param clusterStrategy
     * @return
     */
    public static  Cluster getCluster(String clusterStrategy){
        ClusterEnum clusterEnum = ClusterEnum.getEnum(clusterStrategy);
        Cluster cluster = map.get(clusterEnum);
        if(cluster == null){
            return map.get(ClusterEnum.RANDOM);
        }else {
            return cluster;
        }
    }
}
