package com.wg.neptune.cluster;

import com.wg.neptune.model.ProviderService;

import java.util.List;

/**
 * Created by mc on 18/6/6.
 * 负载均衡接口定义类
 */
public interface Cluster {

    /**
     * 负载均衡算法接口
     * @param providerServices
     * @return
     */
    public ProviderService select(List<ProviderService> providerServices);
}
