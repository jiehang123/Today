package com.wg.neptune.cluster.strategy;

import com.wg.neptune.cluster.Cluster;
import com.wg.neptune.cluster.util.RandomUtil;
import com.wg.neptune.model.ProviderService;

import java.util.List;

/**
 * Created by mc on 18/6/6.
 */
public class RandomClusterStrategy implements Cluster {

    /**
     * 随机负载均衡算法
     * @param providerServices
     * @return
     */
    public ProviderService select(List<ProviderService> providerServices) {
        if(providerServices.size() <= 0){
            return null;
        }
        int length = providerServices.size();
        int index = RandomUtil.getRandomNum(length-1);
        return providerServices.get(index);
    }
}
