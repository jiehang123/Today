package com.wg.neptune.namespace;

import com.wg.neptune.parse.ComsumerDefinitionParser;
import org.springframework.beans.factory.xml.NamespaceHandlerSupport;

/**
 * Created by mc on 18/7/10.
 */
public class RpcReferenceNamespaceHandler extends NamespaceHandlerSupport{

    public void init() {
        registerBeanDefinitionParser("reference", new ComsumerDefinitionParser());
    }
}
