package com.wg.neptune.namespace;

import com.wg.neptune.parse.ServiceDefinitionParser;
import org.springframework.beans.factory.xml.NamespaceHandlerSupport;

/**
 * Created by mc on 18/7/10.
 */
public class RpcServiceNamespaceHandler extends NamespaceHandlerSupport {

    public void init() {
        registerBeanDefinitionParser("service", new ServiceDefinitionParser());
    }
}
