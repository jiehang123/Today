package com.wg.neptune.test;

/**
 * Created by mc on 18/7/10.
 */
public class HelloServiceImpl implements HelloService {

    public String say() {
        return "hello";
    }
}
