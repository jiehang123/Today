package com.wg.neptune.test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * rpc测试类
 */
public class MainClient {

    private static final Logger logger = LoggerFactory.getLogger(MainClient.class);

    public static void main(String[] args) throws Exception {

        //引入远程服务
        final ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("rpc-client.xml");
        //获取远程服务

        final HelloService helloService = (HelloService) context.getBean("helloService");

        //调用服务并打印结果
        try {
            String result = helloService.say();
            System.out.println(result);
        } catch (Exception e) {
            logger.warn("--------", e);
        }
        //关闭jvm
        System.exit(0);
    }
}
