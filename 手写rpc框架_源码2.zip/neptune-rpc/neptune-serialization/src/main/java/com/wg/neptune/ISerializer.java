package com.wg.neptune;

/**
 * 对象序列化 抽象接口
 * Created by mc on 18/5/16.
 */
public interface ISerializer {


    /**
     * 对象序列化
     * @param obj
     * @param <T>
     * @return
     */
    public <T> byte[] serialize(T obj);


    /**
     * 反序列化
     * @param data
     * @param clazz
     * @param <T>
     * @return
     */
    public <T> T deserialize(byte[] data , Class<T> clazz);
}
