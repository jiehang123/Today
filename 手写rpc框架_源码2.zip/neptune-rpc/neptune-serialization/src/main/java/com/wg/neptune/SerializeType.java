package com.wg.neptune;

import org.apache.commons.lang3.StringUtils;

/**
 * Created by mc on 18/5/16.
 */
public enum SerializeType {


    JAVA("java"),

    JACKSON("JACKSON");

    private String value;

    SerializeType( String value){
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


    public static SerializeType queryByType(String serializeType) {
        if (StringUtils.isBlank(serializeType)) {
            return null;
        }

        for (SerializeType serialize : SerializeType.values()) {
            if (StringUtils.equals(serializeType, serialize.getSerializeType())) {
                return serialize;
            }
        }
        return null;
    }

    public String getSerializeType() {
        return value;
    }
}
