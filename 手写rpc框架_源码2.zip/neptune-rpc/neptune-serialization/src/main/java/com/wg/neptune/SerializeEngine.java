package com.wg.neptune;

import com.wg.neptune.jackson.JacksonSerializer;
import com.wg.neptune.java.JavaSerializer;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by mc on 18/5/16.
 */
public class SerializeEngine  {

    public  static final Map<SerializeType,ISerializer> serializeMap = new ConcurrentHashMap<SerializeType, ISerializer>();

    //静态代码块，初始化序列化引擎
    static {
        serializeMap.put(SerializeType.JACKSON, new JacksonSerializer());
        serializeMap.put(SerializeType.JAVA, new JavaSerializer());
    }


    /**
     * 序列化
     * @param serializeType
     * @param obj
     * @param <T>
     * @return
     */
    public <T> byte[] serialize(SerializeType serializeType , T obj){
        ISerializer serializer = serializeMap.get(serializeType);
         return serializer.serialize(obj);
    }

    /**
     * 反序列化
     * @param date
     * @param serializeType
     * @param clazz
     * @param <T>
     * @return
     */
    public <T> T deserialize(byte[] date,SerializeType serializeType,Class<T> clazz){
        ISerializer serializer = serializeMap.get(serializeType);
        return serializer.deserialize(date,clazz);
    }

}
