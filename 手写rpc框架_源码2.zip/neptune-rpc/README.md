## 手写远程调用框架-neptune-rpc

```
项目背景：
	最近一直在看dubbo相关的源码，以及一些dubbo的设计思路，对dubbo的大概的架构设计、大体的实现细节都有了一定得了解。看了架构探险这一系列的书后，想想应该自己实现一套简化的rpc框架，于是开始慢慢的实现、完善neptune-rpc项目。
git地址为：https://gitee.com/wgRoy/neptune-rpc，有兴趣可以一起探讨一下0.0.
```

```
项目框架：
	项目主要由 neptune-serialization、neptune-register、neptune-netty、neptune-cluster、neptune-spring、neptune-proxy六个模块组成。
	neptune-serialization主要是实现了rpc的序列化功能，目前主要有java序列化以及jackson序列两种，其他的序列化方法可以在后续完善下去。另外还实现了一个序列化引擎，提供序列化配置，供用户自己配置序列化的方式。
	neptune-register主要实现了两个功能：1、注册zk服务，将消费者和提供者的服务注册至zookeeper，并且缓存在本地一份监听更新。2、netty通信框架，netty的编解码，以及服务调用。
	neptune-cluster主要实现的是rpc软负载均衡，包括随机、权重随机、轮训、权重轮训、IP hash五种负载均衡算法。提供用户自己配置需要的负载均衡算法。
	neptune-spring主要是实现rpc自定义xml。
	neptune-proxy实现rpc的动态代理，目前仅提供jdk动态代理方式。
整个项目麻雀虽小，五张俱全，可以用来熟悉rpc框架的很多方面的知识。接下来会有几个专题介绍rpc框架的几个重要的知识。
```

