package com.jiehang.tree.avl.impl;

public class AVLTree<T extends Comparable<T>> {
	
	public AVLNode<T> root;
	
	public void insert(T data) {
		if(null == data) {
			throw new RuntimeException("Data cannot be null");
		}
		root = insert(data, root);
	}
	
	public AVLNode<T> insert(T data, AVLNode<T> temNode) {
		if(temNode == null) {
			temNode = new AVLNode<T>(data);
		}else if(data.compareTo(temNode.data) < 0) {
			temNode.left = insert(data, temNode.left);
			temNode.height = temNode.left.height + 1;
		} else if(data.compareTo(temNode.data) > 0) {
			temNode.right = insert(data, temNode.right);
			temNode.height = temNode.right.height + 1;
		} else if(data.compareTo(temNode.data) == 0){
			throw new RuntimeException("Data cannot be duplicated");
		}
		
		// TODO
//		calHeight(temNode);
//		if((temNode.left == null ? 0 : temNode.left.height) > 1 ||  (temNode.right == null ? 0 : temNode.right.height) > 1) {
//			System.out.println("--" + temNode.data);
//		}
		
		return temNode;
	}

//	private void calHeight(AVLNode<T> temNode) {
//		if(temNode)
//	}
	
}
