package org.apache.commons.lang.time;

import org.junit.Test;

public class FastDateFormatTest {
	@Test
	public void test_(){
//		FastDateFormat fastDateFormat = new FastDateFormat(pattern, timeZone, locale);
//		System.out.println(FastDateFormat.parsePattern());
	}
}
