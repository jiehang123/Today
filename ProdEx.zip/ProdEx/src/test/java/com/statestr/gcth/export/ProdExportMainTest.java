package com.statestr.gcth.export;

import org.junit.Test;

import com.statestr.gcth.export.advance.AdvanceExport;

public class ProdExportMainTest {

	// @Test
	public void test_main() {
		String base = "C:/Users/e521907/code/tool/ProdEx/src/main/resources";
		String[] args = { "2016-09-05", "2016-09-06", base + "/INI04_Mar23.xls", base + "/temp.txt", "e521907",
				"201607", base + "/details_mapping.txt", base + "/ini04Prod.sql", "Vicki" };
		ExportMain.mainProcess(args);
	}

	// @Test
	public void test_() {
		String[] args = { "SCHEDULE", "2016-08-07", "C:/LOG/INI04_INAJ.xls", "C:/LOG/temp.txt", "e521907", "201607",
				"C:/LOG/INAJ_details_mapping.txt", "C:/LOG/ini04ProdINAJ.sql", "Vicki" };
		ExportMain.mainProcess(args);
	}

	// @Test
	public void test_trade_pv() {
		String base = "C:/Users/e521907/code/tool/ProdEx/src/main/resources";
		String[] args = { "2016-09-05", "2016-09-06", base + "/INI04_Mar23.xls", base + "/temp.txt", "e521907",
				"201607", base + "/details_mapping.txt", base + "/ini04Prod.sql", "Vicki" };
		ExportMain.mainProcess(args);
	}

//	@Test
	public void test_advance() {
		String base = "C:/Users/e521907/code/tool/ProdEx/src/main/resources";
		String[] args = { "UAT:essss:xxx", base + "/INI04_Mar23.xls", base + "/email.txt",
				base + "/details_mapping.txt", base + "/ini04Prod.sql", base + "/temp.txt", "to_list=Vicki,from_date=${today},to_date=${current}", "SUMM_" };
		AdvanceExport.mainProcess(args);
	}
	
//	@Test
	public void test_advance2() {
		String base = "C:/Users/e521907/code/tool/ProdEx/src/main/resources";
		String[] args = { "SIT:OPGCEP2:OPGCEP2", base + "/2B937407C7A924ACE053CD72010AD3F9.txt", base + "/email.txt",
				base + "/details_mapping.txt", base + "/ini04Prod.sql", base + "/temp.txt", "gc_guid=2B937407C7A924ACE053CD72010AD3F9" };
		AdvanceExport.mainProcess(args);
	}

	@Test
	public void test_wmt() {
		String base = "C:/work/workSpace/GC/ProdEx/src/main/resources";
		String[] args = { "2017-04-13", "2017-04-19", base + "/WMT_Weekly_Report.xls", base + "/email_context.txt", "a620824",
				"Wsx123", base + "/details_mapping.txt", base + "/wmt_weekly_report.sql", "wmt" };
		ExportMain.mainProcess(args);
	}
}
