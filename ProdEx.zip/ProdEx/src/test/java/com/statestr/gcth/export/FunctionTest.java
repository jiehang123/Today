package com.statestr.gcth.export;

import java.text.ParseException;

import org.junit.Test;

import com.statestr.gcth.export.util.Arrange;
import com.statestr.gcth.export.util.PowerfulDateUtil;

public class FunctionTest {
	@Test
	public void test_(){
		String list[] = { "yyyy", "MM", "dd" };
		Arrange ts = new Arrange();
		ts.perm(list, 0, list.length - 1);
		for (int i = 0; i < ts.getArrangeList().size(); i++) {
			System.out.println(ts.getArrangeList().get(i));
		}
		System.out.println("total:" + ts.getTotal());
	}
	
	@Test
	public void test_DateTranform() throws ParseException{
		System.out.println(PowerfulDateUtil.parse("20140908"));
		System.out.println(PowerfulDateUtil.parse("140908"));
		System.out.println(PowerfulDateUtil.parse("091408"));
		System.out.println(PowerfulDateUtil.parse("090814"));
		System.out.println(PowerfulDateUtil.parse("20140908 12:15:12"));
		System.out.println(PowerfulDateUtil.parse("20140908 12:15:12 am"));
		System.out.println(PowerfulDateUtil.parse("2014 09 08 12:15:12 Est"));
		System.out.println(PowerfulDateUtil.parse("2014/09/08 12:15:12 Est"));
		System.out.println(PowerfulDateUtil.parse("140908 12:15:12 Est"));
		System.out.println(PowerfulDateUtil.parse("2014_09_08 12:15:12 Est"));
		System.out.println(PowerfulDateUtil.parse("2014-09-08 12:15:12 Est"));
		System.out.println(PowerfulDateUtil.parse("140908 12:15:12 Est"));
		System.out.println(PowerfulDateUtil.parse("2014/09/08"));
		System.out.println(PowerfulDateUtil.parse("2014-09-08"));
		System.out.println(PowerfulDateUtil.parse("2014_09_08"));
		System.out.println(PowerfulDateUtil.parse("2014 09 08"));
		System.out.println(PowerfulDateUtil.parse("2014 Jun 08"));
		System.out.println(PowerfulDateUtil.parse("2014Jun08"));
		System.out.println(PowerfulDateUtil.parse("Jun201408"));
		System.out.println(PowerfulDateUtil.parse("Jun 2014 08"));
		System.out.println(PowerfulDateUtil.parse("Jun 2014  08"));
		System.out.println(PowerfulDateUtil.parse("Jun-2014-08"));
	}
	
	@Test
	public void test_DateTranform_one() throws ParseException{
		System.out.println(PowerfulDateUtil.parse("2014/09/08"));
	}
	
	
}
