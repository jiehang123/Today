package com.statestr.gcth.export.domain;

import java.util.HashMap;
import java.util.Map;

public class ParameterMap {

	private final Map<String, String>	dataMap	= new HashMap<String, String>();

	public ParameterMap() {
	}

	/**
	* @param sqlParams
	*/
	public ParameterMap(Map<String, String> dataMap) {
		this.dataMap.putAll(dataMap);
	}

	public ParameterMap addValue(String key, String value) {
		this.dataMap.put(key, value);
		return this;
	}

	public Map<String, String> getDataMap() {
		return dataMap;
	}

}
