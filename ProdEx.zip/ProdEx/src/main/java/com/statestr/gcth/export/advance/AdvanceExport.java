/**
 * AdvanceExport.java
 *
 * Copyright (c) 2016 State Street Bank and Trust Corp. 225 Franklin Street, Boston, MA 02110, U.S.A. All rights
 * reserved.
 *
 * "ProdEx is the copyrighted,proprietary property of State Street Bank and Trust Company and its subsidiaries and
 * affiliates which retain all right, title and interest therein."
 *
 */
package com.statestr.gcth.export.advance;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.statestr.gcth.export.domain.AdvanceExportParam;
import com.statestr.gcth.export.domain.EnvEnums;
import com.statestr.gcth.export.domain.SqlParamEnums;

/**
 * @author e521907
 * @version 1.0
 *
 */
public class AdvanceExport {
	/**
	 * 
	 */
	private static final Logger	logger	= Logger.getLogger(AdvanceExport.class);

	public static void main(String[] args) {
		mainProcess(args);
	}

	/**
	 * @param args
	 */
	public static void mainProcess(String[] args) {
		AdvanceExportParam params;
		try {
			validate(args);
			params = new AdvanceExportParam(args);
			enrich(params);
			if (logger.isDebugEnabled()) {
				logger.debug(params);
			}
			ExportHandler exortHandler = new ExportHandler(params);
			exortHandler.export2File();
//			exortHandler.export2Excel();
		} catch (ExceptionInInitializerError e) {
			logger.error("validate error", e);
		}
	}

	private static void validate(String[] args) throws ExceptionInInitializerError {
		if (null == args || args.length < 7) {
			if (null != args) {
				for (int i = 0; i < args.length; i++) {
					logger.info("" + i + " " + args[i]);
				}
			}
			String errorMsg = "you must put 7 parameters, and the sequence is  dbParams,excelPath, emailContentPath, details_mapping file , export sql file,email content Temp file and sqlParams";
			logger.error(errorMsg);
			throw new ExceptionInInitializerError(errorMsg);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("All parameters are below:\n" + StringUtils.join(args, "\n"));
		}
	}

	private static void enrich(AdvanceExportParam params) {
		if(params.getOutputfile().equalsIgnoreCase("SINGLE_RESULT:true")){
			params.setSingleResult(true);
		}
		
		String dbParams = params.getDbParams();
		String[] dbParamArray = StringUtils.split(dbParams, ":");
		if (dbParamArray == null || dbParamArray.length < 3) {
			String errorMsg = "you must input dbParams like UAT:e521222:XXXPW";
			logger.error(errorMsg);
			throw new ExceptionInInitializerError(errorMsg);
		}
		String env = dbParamArray[0];
		String user = dbParamArray[1];
		String pw = dbParamArray[2];
		EnvEnums enve = EnvEnums.codeOf(env);
		if (enve == null) {
			enve = EnvEnums.SIT;
		}
		params.setEnv(enve);
		params.setJdbcUser(user);
		params.setJdbcpw(pw);
		/************************************************************************************/
		String sqlParams = params.getSqlParams();
		String[] paramArray = StringUtils.split(sqlParams, ",");
		if (paramArray == null || paramArray.length == 0) {
			return;
		}
		for (String param : paramArray) {
			String[] pkv = StringUtils.split(param, "=");
			if (pkv == null || pkv.length == 0) {
				continue;
			}
			String key = pkv[0];
			String value = "";
			if (pkv.length > 1) {
				value = pkv[1];
			}
			if (StringUtils.startsWith(value, "#{") && StringUtils.endsWith(value, "}")) {
				String vcode = value.substring("#{".length(), value.length() - 1);
				SqlParamEnums tempv = SqlParamEnums.codeOf(vcode);
				Object objv = tempv != null ? tempv.getGenerator().process().toString() : "";
				value = objv.toString();
			}
			params.getQueryParams().put(key, value);
		}

	}
}
