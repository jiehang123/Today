/**
 * EnvEnums.java
 *
 * Copyright (c) 2016 State Street Bank and Trust Corp. 225 Franklin Street, Boston, MA 02110, U.S.A. All rights
 * reserved.
 *
 * "ProdEx is the copyrighted,proprietary property of State Street Bank and Trust Company and its subsidiaries and
 * affiliates which retain all right, title and interest therein."
 *
 */
package com.statestr.gcth.export.domain;

import org.apache.commons.lang.StringUtils;

/**
 * @author e521907
 * @version 1.0
 *
 */
public enum EnvEnums {
	SIT("sit"),

	UAT("uat"),

	PROD("prod"), ;

	private String	code;

	private EnvEnums(String code) {
		this.code = code;
	}

	/**
	 * @param code
	 * @return
	 */
	public static EnvEnums codeOf(String code) {
		if (StringUtils.isBlank(code)) {
			return null;
		}

		for (EnvEnums temp : EnvEnums.values()) {
			if (StringUtils.equalsIgnoreCase(code, temp.getCode())) {
				return temp;
			}
		}
		return null;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
