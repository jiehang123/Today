package com.statestr.gcth.export.dao.impl;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map.Entry;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.statestr.gcth.export.dao.ExportDao;
import com.statestr.gcth.export.domain.EnvEnums;
import com.statestr.gcth.export.domain.ParameterMap;

public class ExportDaoImpl implements ExportDao {

	private static final Logger	LOGGER			= Logger.getLogger(ExportDaoImpl.class);
	private Connection			connection;
	private Statement			statement;
	private static final String	JDBC_DRIVER		= "jdbc.driverClass";
	private static final String	DB_URL			= "jdbc.url";
	private static final String	USER			= "jdbc.username";
	private static final String	PASSWORD		= "jdbc.password";
	private String				SQL_PATH		= "";

	private static final String	ALERT_SESSION	= "ALTER SESSION SET TIME_ZONE='-5:00'";

	private Properties			properties		= new Properties();

	private void config(String path) throws IOException {
		if (StringUtils.isBlank(path)) {
			path = "prod_db.properties";
		}
		properties.load(this.getClass().getClassLoader().getResourceAsStream(path));
	}

	public ExportDaoImpl() {
	}

	public ExportDaoImpl(String sqlFile) {
		SQL_PATH = sqlFile;
	}

	private void alertSession() {
		try {
			statement.execute(ALERT_SESSION);
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("ALTER SESSION SET TIME_ZONE='-5:00' successfully.");
			}
		} catch (SQLException e) {
			LOGGER.error("error in alert session ... " + e);
		}
	}

	private String getExportSQL(String filePath) {
		BufferedInputStream bufferedReader = null;
		StringBuffer buffer = new StringBuffer();
		try {
			byte[] temp = new byte[1024];
			int bytesRead = 0;
			bufferedReader = new BufferedInputStream(new FileInputStream(new File(filePath)));
			while ((bytesRead = bufferedReader.read(temp)) != -1) {
				buffer.append(new String(temp, 0, bytesRead));
			}
		} catch (FileNotFoundException e) {
			LOGGER.error("FileNotFoundException " + filePath, e);
		} catch (IOException e) {
			LOGGER.error("IOException " + filePath, e);
		} finally {
			try {
				if (null != bufferedReader) {

					bufferedReader.close();
				}
			} catch (IOException e) {
				LOGGER.error("error in close " + filePath, e);
			}
		}
		return buffer.toString();
	}

	private ResultSet query(String sql) {
		try {
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("SQL:" + sql);
			}

			return statement.executeQuery(sql);
		} catch (SQLException e) {
			LOGGER.error("error in execute query ... " + e);
		}
		return null;
	}

	private static String formatSQL(String sql, ParameterMap map) {
		for (Entry<String, String> entry : map.getDataMap().entrySet()) {
			sql = sql.replace(":" + entry.getKey(), "'" + entry.getValue() + "'");
		}
		return sql;
	}

	private void initialDBConnection(String user, String password) {
		try {
			config("prod_db.properties");
			if (null == user || user.trim().length() == 0) {
				user = properties.getProperty(USER);
			}
			if (null == password || password.trim().length() == 0) {
				password = properties.getProperty(PASSWORD);
			}
			Class.forName(properties.getProperty(JDBC_DRIVER)).newInstance();
			// jdbc:oracle:thin:[username/password]@<tns>
			String url = "jdbc:oracle:thin:@" + properties.getProperty(DB_URL);
			connection = DriverManager.getConnection(url, user, password);
			// connection = DriverManager.getConnection(url);
			statement = connection.createStatement();
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("initila DB connection successfully.");
			}
		} catch (Exception e) {
			LOGGER.error("error in initial ... " + e);
		}
	}

	private void initialDBConnection(String user, String password, EnvEnums env) {
		try {
			config("system.properties");
			if (null == user || user.trim().length() == 0) {
				user = properties.getProperty(USER);
			}
			if (null == password || password.trim().length() == 0) {
				password = properties.getProperty(PASSWORD);
			}
			Class.forName(properties.getProperty(JDBC_DRIVER)).newInstance();
			// jdbc:oracle:thin:[username/password]@<tns>
			String url = properties.getProperty(env.getCode() + "." + DB_URL);
			connection = DriverManager.getConnection(url, user, password);
			// connection = DriverManager.getConnection(url);
			statement = connection.createStatement();
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("initila DB connection successfully.");
			}
		} catch (Exception e) {
			LOGGER.error("error in initial ... " + e);
		}
	}

	public void releaseDBResource() {
		if (null != statement) {
			try {
				statement.close();
			} catch (SQLException e) {
				LOGGER.error("close statement error" + e);
			}
		}
		if (null != connection) {
			try {
				connection.close();
			} catch (SQLException e) {
				LOGGER.error("close connection error" + e);
			}
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("release DB resources successfully...");
		}
	}

	@Override
	public ResultSet queryProdDetails(ParameterMap parameterMap, String user, String password) {
		initialDBConnection(user, password);
		alertSession();
		String sqlExport = getExportSQL(SQL_PATH);
		ResultSet result = query(formatSQL(sqlExport, parameterMap));
		return result;
	}

	@Override
	public ResultSet queryProdDetails(ParameterMap parameterMap, String user, String password, EnvEnums env) {
		initialDBConnection(user, password, env);
		String sqlExport = getExportSQL(SQL_PATH);
		ResultSet result = query(formatSQL(sqlExport, parameterMap));
		return result;
	}

}
