package com.statestr.gcth.export.domain;

import java.text.ParseException;
import java.util.Date;

import org.apache.log4j.Logger;

import com.statestr.gcth.export.util.PowerfulDateUtil;

public class ExportObject {
	private static final Logger	LOGGER	= Logger.getLogger(ExportObject.class);

	private Date				fromDate;
	private Date				toDate;
	private String				dbUser;
	private String				password;
	private String				excelPath;
	private String				emailCPath;
	private String				fieldsMappingPath;
	private String				queryPath;
	private String				send2List;
	private String				userId;

	public ExportObject(String[] args) throws ParseException {
		try {
			this.fromDate = PowerfulDateUtil.parse(args[0]);
			this.toDate = PowerfulDateUtil.parse(args[1]);
		} catch (ParseException e) {
			LOGGER.error("cannot parse fromDate/toDate:" + args[0] + "/" + args[1], e);
			throw e;
		}
		this.excelPath = args[2];
		this.emailCPath = args[3];
		this.dbUser = args[4];
		this.password = args[5];
		this.fieldsMappingPath = args[6];
		this.queryPath = args[7];
		this.send2List = args[8];
		if (args.length > 9) {
			this.userId = args[9];
		}
	}

	public Date getFromDate() {
		return fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public String getDbUser() {
		return dbUser;
	}

	public String getPassword() {
		return password;
	}

	public String getExcelPath() {
		return excelPath;
	}

	public String getEmailCPath() {
		return emailCPath;
	}

	public String getFieldsMappingPath() {
		return fieldsMappingPath;
	}

	public String getQueryPath() {
		return queryPath;
	}

	public String getSend2List() {
		return send2List;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "ExportObject's sequence: [fromDate=" + fromDate + ", toDate=" + toDate + ", dbUser=" + dbUser
				+ ", password=" + password + ", excelPath=" + excelPath + ", emailCPath=" + emailCPath
				+ ", fieldsMappingPath=" + fieldsMappingPath + ", queryPath=" + queryPath + ", send2List=" + send2List
				+ "]";
	}

}
