/**
 * AdvanceExportParam.java
 *
 * Copyright (c) 2016 State Street Bank and Trust Corp. 225 Franklin Street, Boston, MA 02110, U.S.A. All rights
 * reserved.
 *
 * "ProdEx is the copyrighted,proprietary property of State Street Bank and Trust Company and its subsidiaries and
 * affiliates which retain all right, title and interest therein."
 *
 */
package com.statestr.gcth.export.domain;

import java.util.HashMap;
import java.util.Map;

/**
 * @author e521907
 * @version 1.0
 *
 */
public class AdvanceExportParam {
	/**
	 * UAT:e521907:XXXPW
	 */
	private String				dbParams;

	/**
	 * UAT/PROD
	 */
	private EnvEnums			env;

	private String				jdbcUser;

	private String				jdbcpw;

	/**
	 * from_date=20150201,to_date=20150301,esf_user=e555556,to_list=all
	 * 
	 * from_date=${TODAY},to_date=20150301,esf_user=e555556,to_list=all
	 */
	private String				sqlParams;

	/**
	 * email content FRE fix
	 * for example: SS_
	 */
	private String				ecParamPreFix;

	private String				outputfile;
	private String				emailCPath;
	private String				fieldsMappingPath;
	private String				queryPath;
	private String				emailTempPath;
	private boolean				singleResult;

	/**
	 * 
	 */
	private Map<String, String>	queryParams	= new HashMap<String, String>();

	public AdvanceExportParam(String[] args) {
		this.dbParams = args[0];
		this.outputfile = args[1];
		this.emailCPath = args[2];
		this.fieldsMappingPath = args[3];
		this.queryPath = args[4];
		this.emailTempPath = args[5];
		this.sqlParams = args[6];
		if (args.length > 7) {
			this.ecParamPreFix = args[7];
		}
	}

	public String getDbParams() {
		return dbParams;
	}

	public void setDbParams(String dbParams) {
		this.dbParams = dbParams;
	}

	public EnvEnums getEnv() {
		return env;
	}

	public void setEnv(EnvEnums env) {
		this.env = env;
	}

	public String getJdbcUser() {
		return jdbcUser;
	}

	public void setJdbcUser(String jdbcUser) {
		this.jdbcUser = jdbcUser;
	}

	public String getJdbcpw() {
		return jdbcpw;
	}

	public void setJdbcpw(String jdbcpw) {
		this.jdbcpw = jdbcpw;
	}

	public String getSqlParams() {
		return sqlParams;
	}

	public void setSqlParams(String sqlParams) {
		this.sqlParams = sqlParams;
	}

	public String getEcParamPreFix() {
		return ecParamPreFix;
	}

	public void setEcParamPreFix(String ecParamPreFix) {
		this.ecParamPreFix = ecParamPreFix;
	}

	public String getOutputfile() {
		return outputfile;
	}

	public void setOutputfile(String outputfile) {
		this.outputfile = outputfile;
	}

	public String getEmailCPath() {
		return emailCPath;
	}

	public void setEmailCPath(String emailCPath) {
		this.emailCPath = emailCPath;
	}

	public String getFieldsMappingPath() {
		return fieldsMappingPath;
	}

	public void setFieldsMappingPath(String fieldsMappingPath) {
		this.fieldsMappingPath = fieldsMappingPath;
	}

	public String getQueryPath() {
		return queryPath;
	}

	public void setQueryPath(String queryPath) {
		this.queryPath = queryPath;
	}

	public String getEmailTempPath() {
		return emailTempPath;
	}

	public void setEmailTempPath(String emailTempPath) {
		this.emailTempPath = emailTempPath;
	}

	public void putQueryParam(String key, String value) {
		queryParams.put(key, value);
	}

	public Map<String, String> getQueryParams() {
		return queryParams;
	}

	public void setQueryParams(Map<String, String> queryParams) {
		this.queryParams = queryParams;
	}

	public boolean isSingleResult() {
		return singleResult;
	}

	public void setSingleResult(boolean singleResult) {
		this.singleResult = singleResult;
	}

	@Override
	public String toString() {
		return "AdvanceExportParam [dbParams=" + dbParams + ", env=" + env + ", jdbcUser=" + jdbcUser + ", jdbcpw="
				+ jdbcpw + ", sqlParams=" + sqlParams + ", ecParamPreFix=" + ecParamPreFix + ", outputfile="
				+ outputfile + ", emailCPath=" + emailCPath + ", fieldsMappingPath=" + fieldsMappingPath
				+ ", queryPath=" + queryPath + ", emailTempPath=" + emailTempPath + ", singleResult=" + singleResult
				+ ", queryParams=" + queryParams + "]";
	}

}
