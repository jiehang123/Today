package com.statestr.gcth.export.dao;

import java.sql.ResultSet;

import com.statestr.gcth.export.domain.EnvEnums;
import com.statestr.gcth.export.domain.ParameterMap;

public interface ExportDao {

	/**
	 * @param parameterMap
	 * @param user
	 * @param password
	 * @return
	 */
	ResultSet queryProdDetails(ParameterMap parameterMap, String user, String password);

	/**
	 * @param parameterMap
	 * @param user
	 * @param password
	 * @param env
	 * @return
	 */
	ResultSet queryProdDetails(ParameterMap parameterMap, String user, String password, EnvEnums env);

	/**
	 * 
	 */
	void releaseDBResource();

}
