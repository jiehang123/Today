package com.statestr.gcth.export.constant;

public class DateFormatPatten {
	public static final String YYYY_MM_DD = "";
	
	
}
