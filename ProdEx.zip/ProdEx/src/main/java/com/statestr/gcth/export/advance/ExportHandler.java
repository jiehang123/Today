/**
 * Export.java
 *
 * Copyright (c) 2016 State Street Bank and Trust Corp. 225 Franklin Street, Boston, MA 02110, U.S.A. All rights
 * reserved.
 *
 * "ProdEx is the copyrighted,proprietary property of State Street Bank and Trust Company and its subsidiaries and
 * affiliates which retain all right, title and interest therein."
 *
 */
package com.statestr.gcth.export.advance;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;

import com.statestr.gcth.export.dao.ExportDao;
import com.statestr.gcth.export.dao.impl.ExportDaoImpl;
import com.statestr.gcth.export.domain.AdvanceExportParam;
import com.statestr.gcth.export.domain.ParameterMap;

/**
 * @author e521907
 * @version 1.0
 *
 */
public class ExportHandler {
	private static final Logger	LOGGER			= Logger.getLogger(ExportHandler.class);
	private static final short	COLOR_HEADER	= IndexedColors.YELLOW.index;
	private static final short	COLOR_ODD		= IndexedColors.GREY_25_PERCENT.index;
	private static final short	COLOR_EVEN		= IndexedColors.GREY_40_PERCENT.index;
	private static final int	VALUE_HIGHT		= 10;
	private static final int	HEADER_HIGHT	= 15;
	private static final String	SHEET_NAME		= "ReportData_Sheet";
	private static final Long	SHEET_MAX_SIZE	= Long.valueOf(65530);

	private String[]			HEADER_VALUE	= {};

	private AdvanceExportParam	exportParam;

	public ExportHandler(AdvanceExportParam exportParam) {
		this.exportParam = exportParam;
		BufferedInputStream bufferedReader = null;
		StringBuffer buffer = new StringBuffer();
		try {
			byte[] temp = new byte[1024];
			int bytesRead = 0;
			bufferedReader = new BufferedInputStream(new FileInputStream(new File(exportParam.getFieldsMappingPath())));
			while ((bytesRead = bufferedReader.read(temp)) != -1) {
				buffer.append(new String(temp, 0, bytesRead));
			}
		} catch (FileNotFoundException e) {
			LOGGER.error("cannot find the " + exportParam.getFieldsMappingPath(), e);
		} catch (IOException e) {
			LOGGER.error("cannot read the " + exportParam.getFieldsMappingPath(), e);
		} finally {
			try {
				if (null != bufferedReader) {
					bufferedReader.close();
				}
			} catch (IOException e) {
				LOGGER.error("close the  bufferedReader for file " + exportParam.getFieldsMappingPath(), e);
			}
		}

		HEADER_VALUE = StringUtils.replace(buffer.toString(), " ", "").split(",");
	}

	public void export2File() {
		if (exportParam.getOutputfile().endsWith(".xls")) {
			export2Excel();
			return;
		}
		if (exportParam.isSingleResult()) {
			singleResult();
			return;
		}
		ExportDao exportDao = new ExportDaoImpl(exportParam.getQueryPath());
		List<StringBuilder> list = new ArrayList<StringBuilder>();
		try {

			ParameterMap parameterMap = new ParameterMap(exportParam.getQueryParams());
			ResultSet result = exportDao.queryProdDetails(parameterMap, exportParam.getJdbcUser(),
					exportParam.getJdbcpw(), exportParam.getEnv());
			while (result.next()) {
				StringBuilder builder = new StringBuilder();
				if (HEADER_VALUE.length == 1) {
					builder.append(result.getString(HEADER_VALUE[0].trim()));
				} else {
					for (int column = 0; column < HEADER_VALUE.length; column++) {
						builder.append(result.getString(HEADER_VALUE[column].trim())).append("\n");
					}
				}
				list.add(builder);
			}
		} catch (SQLException e) {
			LOGGER.error("error in getting ProdDetails..." + e);
		}
		exportDao.releaseDBResource();

		save2Email(0L);

		FileOutputStream fileOut = null;
		OutputStreamWriter osw = null;
		BufferedWriter bw = null;
		try {
			if (list.size() == 0) {
				return;
			}
			if (list.size() == 1) {
				fileOut = new FileOutputStream(exportParam.getOutputfile());
				osw = new OutputStreamWriter(fileOut, "UTF-8");
				bw = new BufferedWriter(osw);
				bw.write(list.get(0).toString());
				bw.flush();
				return;
			}
			String endFix = StringUtils.substring(exportParam.getOutputfile(),
					exportParam.getOutputfile().lastIndexOf("."));
			String freFix = StringUtils.substring(exportParam.getOutputfile(), 0, exportParam.getOutputfile()
					.lastIndexOf("."));
			for (int i = 0; i < list.size(); i++) {
				fileOut = new FileOutputStream(freFix + "_" + (i + 1) + endFix);
				osw = new OutputStreamWriter(fileOut, "UTF-8");
				bw = new BufferedWriter(osw);
				bw.write((list.get(i).toString()));
				bw.flush();
			}
		} catch (Exception e) {
			LOGGER.error("error in save file for " + exportParam.getOutputfile(), e);
		} finally {
			if (fileOut != null) {
				try {
					fileOut.close();
				} catch (IOException e) {
					LOGGER.error("error in close file for " + exportParam.getOutputfile(), e);
				}
			}
		}
	}

	public void singleResult() {
		ExportDao exportDao = new ExportDaoImpl(exportParam.getQueryPath());
		try {

			ParameterMap parameterMap = new ParameterMap(exportParam.getQueryParams());
			ResultSet result = exportDao.queryProdDetails(parameterMap, exportParam.getJdbcUser(),
					exportParam.getJdbcpw(), exportParam.getEnv());
			while (result.next()) {
				for (int column = 0; column < HEADER_VALUE.length; column++) {
					String columnStr = HEADER_VALUE[column].trim();
					String resultStr = result.getString(columnStr);
					exportParam.getQueryParams().put(columnStr, resultStr);
				}
				break;
			}
		} catch (SQLException e) {
			LOGGER.error("error in getting ProdDetails..." + e);
		}
		exportDao.releaseDBResource();

		save2Email(0L);
	}

	public void export2Excel() {
		Long statrAt = System.currentTimeMillis();
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFCellStyle style4Headline = createStyle4Cell(wb, true, false);
		HSSFCellStyle style4Value1 = createStyle4Cell(wb, false, false);
		HSSFCellStyle style4Value2 = createStyle4Cell(wb, false, true);
		HSSFSheet sheet = createSheet(SHEET_NAME + "0", wb, style4Headline);

		ExportDao exportDao = new ExportDaoImpl(exportParam.getQueryPath());
		Long totalSize = Long.valueOf(0);

		ParameterMap parameterMap = new ParameterMap(exportParam.getQueryParams());
		ResultSet result = exportDao.queryProdDetails(parameterMap, exportParam.getJdbcUser(), exportParam.getJdbcpw(),
				exportParam.getEnv());
		try {
			long row = 1;
			int currentSheetRow = 1;
			HSSFSheet currentSheet = sheet;
			while (result.next()) {
				HSSFRow rowValue = currentSheet.createRow(currentSheetRow);

				boolean isFirst = currentSheetRow % 2 != 0;
				for (int column = 0; column < HEADER_VALUE.length; column++) {
					HSSFCell cell = rowValue.createCell(column);
					cell.setCellStyle(isFirst ? style4Value1 : style4Value2);
					String value = result.getString(HEADER_VALUE[column].trim());
					cell.setCellValue(value);
				}
				currentSheetRow++;
				if (row % SHEET_MAX_SIZE == 0) {
					long sheetIndex = row / SHEET_MAX_SIZE;
					currentSheetRow = 1;
					currentSheet = createSheet(SHEET_NAME + String.valueOf(sheetIndex), wb, style4Headline);
				}
				row++;
			}
			totalSize = totalSize + Long.valueOf(row) + Long.valueOf(-1);
		} catch (SQLException e) {
			LOGGER.error("error in getting ProdDetails..." + e);
		}
		exportDao.releaseDBResource();

		save2Email(totalSize);

		save2Excel(wb);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Total time is:" + (System.currentTimeMillis() - statrAt));
		}
	}

	private void save2Email(Long totalSize) {
		BufferedInputStream bufferedReader = null;
		StringBuffer buffer = new StringBuffer();
		try {
			byte[] temp = new byte[1024];
			int bytesRead = 0;
			bufferedReader = new BufferedInputStream(new FileInputStream(new File(exportParam.getEmailTempPath())));
			while ((bytesRead = bufferedReader.read(temp)) != -1) {
				buffer.append(new String(temp, 0, bytesRead));
			}
		} catch (FileNotFoundException e) {
			LOGGER.error("cannot find the " + exportParam.getEmailTempPath(), e);
		} catch (IOException e) {
			LOGGER.error("cannot read the " + exportParam.getEmailTempPath(), e);
		} finally {
			try {
				if (null != bufferedReader) {
					bufferedReader.close();
				}
			} catch (IOException e) {
				LOGGER.error("close the  bufferedReader for file " + exportParam.getEmailTempPath(), e);
			}
		}
		//
		exportParam.getQueryParams().put("total", String.valueOf(totalSize));
		String emailContant = enrichContant(buffer.toString(), exportParam.getQueryParams(),
				exportParam.getEcParamPreFix());
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Email content:");
			LOGGER.debug("\n" + emailContant.toString());
			LOGGER.debug("////////////////");
		}
		String tempDest = exportParam.getEmailCPath();
		File file = new File(tempDest);
		FileOutputStream fileOut = null;
		try {
			fileOut = new FileOutputStream(file);
			emailContant = emailContant.replace("${", "{");
			emailContant = emailContant.replace("$", "\\$");
			emailContant = emailContant.replace("{", "${");
			fileOut.write(emailContant.getBytes());

		} catch (Exception e) {
			LOGGER.error("error in save file for " + tempDest, e);
		} finally {
			if (fileOut != null) {
				try {
					fileOut.close();
				} catch (IOException e) {
					LOGGER.error("error in close file for " + tempDest, e);
				}
			}
		}
	}

	private String enrichContant(String emailContant, Map<String, String> params, String preFix) {
		preFix = StringUtils.isBlank(preFix) ? "" : preFix;
		for (Entry<String, String> entry : params.entrySet()) {
			String key = StringUtils.join(new String[] { "${", preFix, entry.getKey(), "}" });
			String value = entry.getValue();
			key = StringUtils.isBlank(key) ? "" : key;
			value = StringUtils.isBlank(value) ? "" : value;
			emailContant = emailContant.replace(key, value);
		}
		return emailContant;
	}

	private void save2Excel(HSSFWorkbook wb) {
		FileOutputStream fileOut = null;
		String detination = exportParam.getOutputfile();
		try {
			if (null != detination && detination.trim().length() > 0) {
				detination = detination.trim().replace("-", "_");
				if (detination.length() > 4
						&& !detination.substring(detination.length() - 4, detination.length()).equalsIgnoreCase(".xls")) {
					detination = detination + ".xls";
				} else if (detination.length() <= 4) {
					detination = detination + ".xls";
				}
			}
			fileOut = new FileOutputStream(detination);
			wb.write(fileOut);
		} catch (Exception e) {
			LOGGER.error("error in save Excel for " + detination, e);
		} finally {
			if (fileOut != null) {
				try {
					fileOut.close();
				} catch (IOException e) {
					LOGGER.error("error in close file for " + detination, e);
				}
			}
		}
	}

	private HSSFCellStyle createStyle4Cell(HSSFWorkbook wb, boolean isHeaderline, boolean isFirst) {
		HSSFCellStyle style = wb.createCellStyle();
		Font font = wb.createFont();
		style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		if (isHeaderline) {
			style.setFillForegroundColor(COLOR_HEADER);
			style.setFillBackgroundColor(COLOR_HEADER);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			font.setFontHeightInPoints((short) HEADER_HIGHT);
		} else {
			if (isFirst) {
				style.setFillForegroundColor(COLOR_ODD);
				style.setFillBackgroundColor(COLOR_ODD);
			} else {
				style.setFillForegroundColor(COLOR_EVEN);
				style.setFillBackgroundColor(COLOR_EVEN);
			}
			font.setFontHeightInPoints((short) VALUE_HIGHT);
		}
		style.setBorderBottom((short) 1);
		style.setBorderLeft((short) 1);
		style.setBorderRight((short) 1);
		style.setBorderTop((short) 1);
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		font.setFontName("Courier New");
		// font.setItalic(isHeaderline);
		// font.setStrikeout(isHeaderline);
		style.setFont(font);
		return style;
	}

	private HSSFSheet createSheet(String name, HSSFWorkbook wb, HSSFCellStyle style4Headline) {
		HSSFSheet sheet = wb.createSheet(name);
		for (int i = 0; i < HEADER_VALUE.length; i++) {
			sheet.setColumnWidth((short) i, 20 * 256);
		}
		sheet.setDefaultRowHeight((short) 300);
		HSSFRow rowHeader = sheet.createRow(0);
		rowHeader.setHeightInPoints(HEADER_HIGHT);
		for (int column = 0; column < HEADER_VALUE.length; column++) {
			HSSFCell cell = rowHeader.createCell(column);
			cell.setCellStyle(style4Headline);
			cell.setCellValue(HEADER_VALUE[column]);
		}
		return sheet;
	}
}
