/**
 * SqlParamEnums.java
 *
 * Copyright (c) 2016 State Street Bank and Trust Corp. 225 Franklin Street, Boston, MA 02110, U.S.A. All rights
 * reserved.
 *
 * "ProdEx is the copyrighted,proprietary property of State Street Bank and Trust Company and its subsidiaries and
 * affiliates which retain all right, title and interest therein."
 *
 */
package com.statestr.gcth.export.domain;

import org.apache.commons.lang.StringUtils;

import com.statestr.gcth.export.util.DateUtils;

/**
 * @author e521907
 * @version 1.0
 *
 */
public enum SqlParamEnums {
	TODAY("today", new ValueGenerator() {
		@Override
		public Object process() {
			return DateUtils.getWebDateString(DateUtils.now());
		}
	}),

	CURRENT("current", new ValueGenerator() {
		@Override
		public Object process() {
			return DateUtils.getNewFormatDateString(DateUtils.now());
		}
	}),

	TOMORROW("tomorrow", new ValueGenerator() {
		@Override
		public Object process() {
			return DateUtils.getWebDateString(DateUtils.addDays(DateUtils.now(), 1));
		}
	}),

	YESTODAY("yestoday", new ValueGenerator() {
		@Override
		public Object process() {
			return DateUtils.getWebDateString(DateUtils.addDays(DateUtils.now(), -1));
		}
	}),

	;
	private String			code;

	private ValueGenerator	generator;

	private SqlParamEnums(String code, ValueGenerator generator) {
		this.code = code;
		this.generator = generator;
	}

	public static SqlParamEnums codeOf(String code) {
		if (StringUtils.isBlank(code)) {
			return null;
		}
		for (SqlParamEnums temp : values()) {
			if (StringUtils.equalsIgnoreCase(code, temp.code)) {
				return temp;
			}
		}
		return null;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public ValueGenerator getGenerator() {
		return generator;
	}

	public void setGenerator(ValueGenerator generator) {
		this.generator = generator;
	}

	public interface ValueGenerator {
		Object process();
	}

}
