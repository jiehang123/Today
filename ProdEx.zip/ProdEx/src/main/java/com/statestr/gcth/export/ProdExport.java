package com.statestr.gcth.export;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;

import com.statestr.gcth.export.dao.ExportDao;
import com.statestr.gcth.export.dao.impl.ExportDaoImpl;
import com.statestr.gcth.export.domain.ExportObject;
import com.statestr.gcth.export.domain.ParameterMap;
import com.statestr.gcth.export.util.UtilTools;

public class ProdExport {
	private static final Logger	LOGGER				= Logger.getLogger(ProdExport.class);
	private static final short	COLOR_HEADER		= IndexedColors.YELLOW.index;
	private static final short	COLOR_ODD			= IndexedColors.GREY_25_PERCENT.index;
	private static final short	COLOR_EVEN			= IndexedColors.GREY_40_PERCENT.index;
	private static final int	VALUE_HIGHT			= 10;
	private static final int	HEADER_HIGHT		= 15;
	private static final String	PROD_REPORT_DATA	= "PROD_ReportData_Sheet";
	private static final Long	SHEET_MAX_SIZE		= Long.valueOf(65530);

	private String[]			HEADER_VALUE		= { "GEO_CD", "USE_CASE_ID", "RESOLUTION_CREATED_AT",
			"RESOLUTION_CODE", "RESOLUTION_NAME", "INI04_MESG", "SOURCE_ID", "SOURCE_TRANS_CD", "FUND_ID",
			"INV_TYP_CD", "SSB_TRADE_ID", "SSB_ASSET_ID", "GC_GUID", "TRANS_AMT", "GC_CLASS_CD", "SETTLE_CCY_CD",
			"VALUE_DATE", "TXN_JUSTIFICATION", "ISSUE_DESC_TXT", "TRANS_CAME_IN_AT" };

	private ExportObject		exObject;

	public ProdExport(ExportObject exObject) {
		this.exObject = exObject;
		BufferedInputStream bufferedReader = null;
		StringBuffer buffer = new StringBuffer();
		try {
			byte[] temp = new byte[1024];
			int bytesRead = 0;
			bufferedReader = new BufferedInputStream(new FileInputStream(new File(exObject.getFieldsMappingPath())));
			while ((bytesRead = bufferedReader.read(temp)) != -1) {
				buffer.append(new String(temp, 0, bytesRead));
			}
		} catch (FileNotFoundException e) {
			LOGGER.error("cannot find the " + exObject.getFieldsMappingPath(), e);
		} catch (IOException e) {
			LOGGER.error("cannot read the " + exObject.getFieldsMappingPath(), e);
		} finally {
			try {
				if (null != bufferedReader) {
					bufferedReader.close();
				}
			} catch (IOException e) {
				LOGGER.error("close the  bufferedReader for file " + exObject.getFieldsMappingPath(), e);
			}
		}

		HEADER_VALUE = StringUtils.replace(buffer.toString(), " ", "").split(",");
	}

	public void export2Excel() {
		Long statrAt = System.currentTimeMillis();
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFCellStyle style4Headline = createStyle4Cell(wb, true, false);
		HSSFCellStyle style4Value1 = createStyle4Cell(wb, false, false);
		HSSFCellStyle style4Value2 = createStyle4Cell(wb, false, true);
		HSSFSheet sheet = createSheet(PROD_REPORT_DATA + "0", wb, style4Headline);

		ExportDao exportDao = new ExportDaoImpl(exObject.getQueryPath());
		Long totalSize = Long.valueOf(0);

		Long errorSize = Long.valueOf(0);
		ParameterMap parameterMap = new ParameterMap()
				.addValue("from_date", UtilTools.dateFormat(exObject.getFromDate()))
				.addValue("to_date", UtilTools.dateFormat(exObject.getToDate()))
				.addValue("user_id", exObject.getUserId());
		ResultSet result = exportDao.queryProdDetails(parameterMap, exObject.getDbUser(), exObject.getPassword());
		try {
			long row = 1;
			int currentSheetRow = 1;
			HSSFSheet currentSheet = sheet;
			while (result.next()) {
				HSSFRow rowValue = currentSheet.createRow(currentSheetRow);

				boolean isFirst = currentSheetRow % 2 != 0;
				for (int column = 0; column < HEADER_VALUE.length; column++) {
					HSSFCell cell = rowValue.createCell(column);
					cell.setCellStyle(isFirst ? style4Value1 : style4Value2);
					String value = result.getString(HEADER_VALUE[column].trim());
					cell.setCellValue(value);
				}
				currentSheetRow++;
				if (row % SHEET_MAX_SIZE == 0) {
					long sheetIndex = row / SHEET_MAX_SIZE;
					currentSheetRow = 1;
					currentSheet = createSheet(PROD_REPORT_DATA + String.valueOf(sheetIndex), wb, style4Headline);
				}
				row++;
			}
			totalSize = totalSize + Long.valueOf(row) + Long.valueOf(-1);
		} catch (SQLException e) {
			LOGGER.error("error in getting INI04ProdDetails..." + e);
		}
		exportDao.releaseDBResource();
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("ERROR transaction total size is:" + errorSize);
		}

		save2Email(errorSize, totalSize);

		save2Excel(wb);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Total time is:" + (System.currentTimeMillis() - statrAt));
		}
	}

	private void save2Email(Long errorSize, Long totalSize) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("<P>").append("Hi ").append(exObject.getSend2List()).append(",</P>");
		// There are 7275 transactions flow into INI04 on Mar-26-2014 and below transaction got error with error
		// message.
		buffer.append("<P>").append("Here are the reports ");

		if (UtilTools.isDateEquals(exObject.getFromDate(), exObject.getToDate())) {
			buffer.append("on ").append(UtilTools.dateFormat(exObject.getFromDate(), "MMM-dd-yyyy"));
		} else {
			buffer.append("from ").append(UtilTools.dateFormat(exObject.getFromDate(), "MMM-dd-yyyy"));
			buffer.append(" to ");
			buffer.append(UtilTools.dateFormat(exObject.getToDate(), "MMM-dd-yyyy"));
		}

		buffer.append(". ");
		// buffer.append(errorSize);
		// buffer.append("  transactions got error.");
		buffer.append("</P>");
		buffer.append("<br/>").append("<br/>").append("<br/>").append("<br/>").append("<br/>");

		buffer.append("<P>").append("Thanks and regards");
		buffer.append("<P>").append("GOLD COPY SUPPORT");
		buffer.append("<P>")
				.append("----------------------------------------------------------------------------------------- ")
				.append("</P>");
		String informationOnly = "The information contained in this email and any attachments have been classified as limited access and/or privileged State Street information/communication and is intended solely for the use of the named addressee(s).  If you are not an intended recipient or a person responsible for delivery to an intended recipient, please notify the author and destroy this email.  Any unauthorized copying, disclosure, retention or distribution of the material in this email is strictly forbidden Limited Access";
		buffer.append(informationOnly);
		//
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Email content:");
			LOGGER.debug("\n" + buffer.toString());
			LOGGER.debug("////////////////");
		}
		String tempDest = exObject.getEmailCPath();
		File file = new File(tempDest);
		FileOutputStream fileOut = null;
		// Writer writer = null;
		try {
			// writer = new FileWriter(file);
			fileOut = new FileOutputStream(file);
			// StringEscapeUtils.unescapeHtml(writer, buffer.toString());
			// StringEscapeUtils.escapeHtml(writer, buffer.toString());
			// $ u0024 == $

			// u0040 == @
			fileOut.write(buffer.toString().replace("$", "\\$").getBytes());

		} catch (Exception e) {
			LOGGER.error("error in save file for " + tempDest, e);
		} finally {
			if (fileOut != null) {
				try {
					fileOut.close();
				} catch (IOException e) {
					LOGGER.error("error in close file for " + tempDest, e);
				}
			}
		}
	}

	private void save2Excel(HSSFWorkbook wb) {
		FileOutputStream fileOut = null;
		String detination = exObject.getExcelPath();
		try {
			if (null != detination && detination.trim().length() > 0) {
				detination = detination.trim().replace("-", "_");
				if (detination.length() > 4
						&& !detination.substring(detination.length() - 4, detination.length()).equalsIgnoreCase(".xls")) {
					detination = detination + ".xls";
				} else if (detination.length() <= 4) {
					detination = detination + ".xls";
				}
			}
			fileOut = new FileOutputStream(detination);
			wb.write(fileOut);
		} catch (Exception e) {
			LOGGER.error("error in save Excel for " + detination, e);
		} finally {
			if (fileOut != null) {
				try {
					fileOut.close();
				} catch (IOException e) {
					LOGGER.error("error in close file for " + detination, e);
				}
			}
		}
	}

	private HSSFCellStyle createStyle4Cell(HSSFWorkbook wb, boolean isHeaderline, boolean isFirst) {
		HSSFCellStyle style = wb.createCellStyle();
		Font font = wb.createFont();
		style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		if (isHeaderline) {
			style.setFillForegroundColor(COLOR_HEADER);
			style.setFillBackgroundColor(COLOR_HEADER);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			font.setFontHeightInPoints((short) HEADER_HIGHT);
		} else {
			if (isFirst) {
				style.setFillForegroundColor(COLOR_ODD);
				style.setFillBackgroundColor(COLOR_ODD);
			} else {
				style.setFillForegroundColor(COLOR_EVEN);
				style.setFillBackgroundColor(COLOR_EVEN);
			}
			font.setFontHeightInPoints((short) VALUE_HIGHT);
		}
		style.setBorderBottom((short) 1);
		style.setBorderLeft((short) 1);
		style.setBorderRight((short) 1);
		style.setBorderTop((short) 1);
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		font.setFontName("Courier New");
		// font.setItalic(isHeaderline);
		// font.setStrikeout(isHeaderline);
		style.setFont(font);
		return style;
	}

	private HSSFSheet createSheet(String name, HSSFWorkbook wb, HSSFCellStyle style4Headline) {
		HSSFSheet sheet = wb.createSheet(name);
		for (int i = 0; i < HEADER_VALUE.length; i++) {
			sheet.setColumnWidth((short) i, 20 * 256);
		}
		sheet.setDefaultRowHeight((short) 300);
		HSSFRow rowHeader = sheet.createRow(0);
		rowHeader.setHeightInPoints(HEADER_HIGHT);
		for (int column = 0; column < HEADER_VALUE.length; column++) {
			HSSFCell cell = rowHeader.createCell(column);
			cell.setCellStyle(style4Headline);
			cell.setCellValue(HEADER_VALUE[column]);
		}
		return sheet;
	}
}
