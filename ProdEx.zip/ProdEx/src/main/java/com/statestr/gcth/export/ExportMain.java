package com.statestr.gcth.export;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.statestr.gcth.export.domain.ExportObject;
import com.statestr.gcth.export.util.PowerfulDateUtil;
import com.statestr.gcth.export.util.UtilTools;

public class ExportMain {
	private static final Logger	LOGGER		= Logger.getLogger(ExportMain.class);
	private static final String	SCHEDULE	= "SCHEDULE";

	public static void main(String[] args) {
		mainProcess(args);
	}

	public static void mainProcess(String[] args) {
		ExportObject exObject;
		try {
			validate(args);
			exObject = new ExportObject(args);
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(exObject);
			}
			ProdExport prodExort = new ProdExport(exObject);
			prodExort.export2Excel();
		} catch (ParseException e) {
			LOGGER.error("export error", e);
		} catch (ExceptionInInitializerError e) {
			LOGGER.error("validate error", e);
		}
	}

	private static void validate(String[] args) throws ExceptionInInitializerError {
		if (null == args || args.length < 9) {
			if (null != args) {
				for (int i = 0; i < args.length; i++) {
					LOGGER.info("" + i + " " + args[i]);
				}
			}
			String errorMsg = "you must put 9 parameters, and the sequence is fromDateStr, toDateStr, excelPath, emailContentPath, prodUser , password, details_mapping file and export sql file";
			LOGGER.error(errorMsg);
			throw new ExceptionInInitializerError(errorMsg);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("All parameters are below:\n" + StringUtils.join(args, "\n"));
		}
		dateConvert(args);
	}

	private static void dateConvert(String[] args) {
		String switchFlg = args[0];
		if (StringUtils.equalsIgnoreCase(SCHEDULE, switchFlg.trim())) {
			String dateStr = args[1];
			Date today = UtilTools.getCurrentDate();
			try {
				today = PowerfulDateUtil.parse(dateStr);
			} catch (ParseException e) {
			}
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Current time is : " + UtilTools.dateFormat(today, "yyyy/MM/dd HH:mm:ss z"));
			}
			if (UtilTools.isMonday(today)) {
				args[0] = UtilTools.dateFormat(today, -4);
				args[1] = UtilTools.dateFormat(today, 0);
			} else if (UtilTools.isTuesday(today)) {
				args[0] = UtilTools.dateFormat(today, -5);
				args[1] = UtilTools.dateFormat(today, -1);
			} else if (UtilTools.isWednesday(today)) {
				args[0] = UtilTools.dateFormat(today, -1);
				args[1] = UtilTools.dateFormat(today, 0);
			} else if (UtilTools.isThursday(today)) {
				args[0] = UtilTools.dateFormat(today, -2);
				args[1] = UtilTools.dateFormat(today, -1);
			}
		}
	}

}
