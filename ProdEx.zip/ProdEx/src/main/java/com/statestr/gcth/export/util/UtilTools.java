package com.statestr.gcth.export.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.time.DateUtils;

public class UtilTools {
	public static String dateFormat(Date date) {
		return dateFormat(date, "yyyy-MM-dd");
	}

	public static String dateFormat(Date date, int dayOfYear) {
		return dateFormat(add(date, dayOfYear), "yyyy-MM-dd");
	}

	public static String dateFormat(Date date, String format) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
		return simpleDateFormat.format(date);
	}

	public static Date string2Date(String dateStr, String format) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
		try {
			return simpleDateFormat.parse(dateStr);
		} catch (ParseException e) {

		}
		return null;
	}

	public static Date add(Date date, int dayOfYear) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_YEAR, dayOfYear);
		return calendar.getTime();
	}

	public static boolean isDateEquals(Date date1, Date date2) {
		return DateUtils.isSameDay(date1, date2);
	}

	public static Date getCurrentDate() {
		return Calendar.getInstance().getTime();
	}

	public static String getCurrentDateStr(String format) {
		return dateFormat(getCurrentDate(), format);
	}

	public static boolean isMonday(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return Calendar.MONDAY == calendar.get(Calendar.DAY_OF_WEEK);
	}

	public static boolean isTuesday(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return Calendar.TUESDAY == calendar.get(Calendar.DAY_OF_WEEK);
	}

	public static boolean isWednesday(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return Calendar.WEDNESDAY == calendar.get(Calendar.DAY_OF_WEEK);
	}

	public static boolean isThursday(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return Calendar.THURSDAY == calendar.get(Calendar.DAY_OF_WEEK);
	}

}
